<div class="col-xl-4 col-md-6">
    <a href="assets/img/granite/1.png" class="img-popup">
        <div class="gallery-card style3">
            <div class="gallery-thumb">
                <img src="assets/img/granite/1.png" alt="thumb" />
            </div>
        </div>
    </a>
</div>

<div class="col-xl-4 col-md-6">
    <a href="assets/img/granite/2.png" class="img-popup">
        <div class="gallery-card style3">
            <div class="gallery-thumb">
                <img src="assets/img/granite/2.png" alt="thumb" />
            </div>
        </div>
    </a>
</div>