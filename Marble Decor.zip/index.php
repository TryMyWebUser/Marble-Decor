<!DOCTYPE html>
<html lang="zxx">
    <!--<< Header Area >>-->
    <head>
        <!-- ========== Meta Tags ========== -->
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />

        <?php include "temp/head.php" ?>

    </head>

    <body>
        <?php include "temp/header.php" ?>

        <!-- Intro Section  S T A R T -->
        <div class="intro-section fix">
            <div class="slider-area introSliderOne">
                <div class="swiper gt-slider" id="introSliderOne" data-slider-options='{"loop": true, "effect": "fade"}'>
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="intro-wrapper style1 fix section-padding bg-img">
                                <div class="shape"><img src="assets/images/shape/heroShape1_1.png" alt="shape" /></div>
                                <div class="gt-hero-bg" data-bg-src="assets/images/bg/introBg1_1.jpg"></div>
                                <div class="container">
                                    <div class="intro-content-wrapper style1" data-animation="slideInLeft" data-duration="2s" data-delay="0.3s">
                                        <div class="row gy-5 d-flex align-items-center">
                                            <div class="col-xl-6">
                                                <div class="intro-content">
                                                    <div class="section-title text-start mt-70">
                                                        <div class="subtitle text-start" data-ani="slideindown" data-ani-delay="0.3s">
                                                            <img class="me-1" src="assets/images/shape/titleShape1_1.png" alt="icon" /> Welcome to
                                                        </div>
                                                        <h1 class="text-start mt-15" data-ani="slideindown" data-ani-delay="0.5s">
                                                            Marble Decor
                                                        </h1>
                                                        <p class="desc" data-ani="slideinup" data-ani-delay="0.8s">
                                                            Marble Decor is one of the most reputed wholesale & retail dealers of premium flooring products in South India.
                                                        </p>
                                                    </div>

                                                    <div class="btn-wrapper style2" data-ani="slideinup" data-ani-delay="1s">
                                                        <a href="https://wa.me/+919952442369" class="theme-btn style3">
                                                            For Enquiry
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="41" height="26" viewBox="0 0 41 26" fill="none">
                                                                <rect width="1" height="26" fill="#2B1E16"></rect>
                                                                <path
                                                                    d="M40.7071 13.7071C41.0976 13.3166 41.0976 12.6834 40.7071 12.2929L34.3431 5.92893C33.9526 5.53841 33.3195 5.53841 32.9289 5.92893C32.5384 6.31946 32.5384 6.95262 32.9289 7.34315L38.5858 13L32.9289 18.6569C32.5384 19.0474 32.5384 19.6805 32.9289 20.0711C33.3195 20.4616 33.9526 20.4616 34.3431 20.0711L40.7071 13.7071ZM15 14H40V12H15V14Z"
                                                                    fill="#2B1E16"
                                                                ></path>
                                                            </svg>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-6">
                                                <div class="intro-thumb" data-ani="slideinright" data-ani-delay="0.7s">
                                                    <img src="assets/images/intro/introThumb1_1.png" alt="thumb" />

                                                    <div class="video-wrap ripple-effect rounded-0">
                                                        <div class="video-preview" style="background-image: url('assets/images/video-preview-1.jpg');">
                                                            <a href="#" class="play-btn" data-video-src="assets/img/VID-20250424-WA0001.mp4">
                                                                <img class="playerImg" src="assets/images/icon/playerIcon1_2.svg" alt="Play video">
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="intro-wrapper style1 fix section-padding bg-img">
                                <div class="shape"><img src="assets/images/shape/heroShape1_1.png" alt="shape" /></div>
                                <div class="gt-hero-bg" data-bg-src="assets/images/bg/introBg1_1.jpg"></div>
                                <div class="container">
                                    <div class="intro-content-wrapper style1" data-animation="slideInLeft" data-duration="2s" data-delay="0.3s">
                                        <div class="row gy-5 d-flex align-items-center">
                                            <div class="col-xl-6">
                                                <div class="intro-content">
                                                    <div class="section-title text-start mt-70">
                                                        <div class="subtitle text-start" data-ani="slideindown" data-ani-delay="0.3s">
                                                            <img class="me-1" src="assets/images/shape/titleShape1_1.png" alt="icon" /> Welcome to
                                                        </div>
                                                        <h1 class="text-start mt-15" data-ani="slideindown" data-ani-delay="0.5s">
                                                            Marble Decor
                                                        </h1>
                                                        <p class="desc" data-ani="slideinup" data-ani-delay="0.8s">
                                                            Marble Decor is one of the most reputed wholesale & retail dealers of premium flooring products in South India.
                                                        </p>
                                                    </div>

                                                    <div class="btn-wrapper style2" data-ani="slideinup" data-ani-delay="1s">
                                                        <a href="https://wa.me/+919952442369" class="theme-btn style3">
                                                            For Enquiry
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="41" height="26" viewBox="0 0 41 26" fill="none">
                                                                <rect width="1" height="26" fill="#2B1E16"></rect>
                                                                <path
                                                                    d="M40.7071 13.7071C41.0976 13.3166 41.0976 12.6834 40.7071 12.2929L34.3431 5.92893C33.9526 5.53841 33.3195 5.53841 32.9289 5.92893C32.5384 6.31946 32.5384 6.95262 32.9289 7.34315L38.5858 13L32.9289 18.6569C32.5384 19.0474 32.5384 19.6805 32.9289 20.0711C33.3195 20.4616 33.9526 20.4616 34.3431 20.0711L40.7071 13.7071ZM15 14H40V12H15V14Z"
                                                                    fill="#2B1E16"
                                                                ></path>
                                                            </svg>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-6">
                                                <div class="intro-thumb" data-ani="slideinright" data-ani-delay="0.7s">
                                                    <img src="assets/images/intro/introThumb1_2.png" alt="thumb" />

                                                    <div class="video-wrap ripple-effect rounded-0">
                                                        <div class="video-preview" style="background-image: url('assets/images/video-preview-1.jpg');">
                                                            <a href="#" class="play-btn" data-video-src="assets/img/VID-20250424-WA0002.mp4">
                                                                <img class="playerImg" src="assets/images/icon/playerIcon1_2.svg" alt="Play video">
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="intro-wrapper style1 fix section-padding bg-img">
                                <div class="shape"><img src="assets/images/shape/heroShape1_1.png" alt="shape" /></div>
                                <div class="gt-hero-bg" data-bg-src="assets/images/bg/introBg1_1.jpg"></div>
                                <div class="container">
                                    <div class="intro-content-wrapper style1" data-animation="slideInLeft" data-duration="2s" data-delay="0.3s">
                                        <div class="row gy-5 d-flex align-items-center">
                                            <div class="col-xl-6">
                                                <div class="intro-content">
                                                    <div class="section-title text-start mt-70">
                                                        <div class="subtitle text-start" data-ani="slideindown" data-ani-delay="0.3s">
                                                            <img class="me-1" src="assets/images/shape/titleShape1_1.png" alt="icon" /> Welcome to
                                                        </div>
                                                        <h1 class="text-start mt-15" data-ani="slideindown" data-ani-delay="0.5s">
                                                            Marble Decor
                                                        </h1>
                                                        <p class="desc" data-ani="slideinup" data-ani-delay="0.8s">
                                                            Marble Decor is one of the most reputed wholesale & retail dealers of premium flooring products in South India.
                                                        </p>
                                                    </div>

                                                    <div class="btn-wrapper style2" data-ani="slideinup" data-ani-delay="1s">
                                                        <a href="https://wa.me/+919952442369" class="theme-btn style3">
                                                            For Enquiry
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="41" height="26" viewBox="0 0 41 26" fill="none">
                                                                <rect width="1" height="26" fill="#2B1E16"></rect>
                                                                <path
                                                                    d="M40.7071 13.7071C41.0976 13.3166 41.0976 12.6834 40.7071 12.2929L34.3431 5.92893C33.9526 5.53841 33.3195 5.53841 32.9289 5.92893C32.5384 6.31946 32.5384 6.95262 32.9289 7.34315L38.5858 13L32.9289 18.6569C32.5384 19.0474 32.5384 19.6805 32.9289 20.0711C33.3195 20.4616 33.9526 20.4616 34.3431 20.0711L40.7071 13.7071ZM15 14H40V12H15V14Z"
                                                                    fill="#2B1E16"
                                                                ></path>
                                                            </svg>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-6">
                                                <div class="intro-thumb" data-ani="slideinright" data-ani-delay="0.7s">
                                                    <img src="assets/images/intro/introThumb1_3.png" alt="thumb" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="slider-arrow-btn text-end wow fadeInUp" data-wow-delay=".9s">
                        <button data-slider-prev="#introSliderOne" class="slider-arrow style1 slider-prev"><i class="fa-solid fa-arrow-left-long"></i></button>
                        <button data-slider-next="#introSliderOne" class="slider-arrow style1 slider-next"><i class="fa-solid fa-arrow-right-long"></i></button>
                    </div>
                    <div class="pagination-class swiper-pagination"></div>
                </div>
            </div>
        </div>

        <!-- About Section    S T A R T -->
        <section class="about-section">
            <div class="about-container-wrapper style2 section-padding fix bg-white">
                <div class="container">
                    <div class="about-wrapper style2">
                        <div class="row gy-5 gx-60">
                            <div class="col-xl-6">
                                <div class="about-thumb img-custom-anim-left wow fadeInUp" data-wow-delay=".3s">
                                    <div class="thumbShape1"><img src="assets/images/shape/aboutshape1_1.png" alt="thumbshape" /></div>

                                    <div class="thumbShape2"><img src="assets/images/shape/aboutThumbshape3_1.png" alt="thumbshape" /></div>

                                    <img class="thumb1" src="assets/images/about/aboutThumb2_1.jpg" alt="thumb" />
                                    <img class="thumb2" src="assets/images/about/aboutThumb2_2.jpg" alt="thumb" />
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="about-content">
                                    <div class="section-title text-start mt-70">
                                        <div class="subtitle text-start wow fadeInUp" data-wow-delay=".5s"><img class="me-1" src="assets/images/shape/titleShape1_1.png" alt="icon" /> ABOUT US</div>
                                        <h2 class="text-start mt-15 wow fadeInUp" data-wow-delay=".3s">Marble Decor</h2>
                                        <p class="desc wow fadeInUp" data-wow-delay=".5s">
                                            Marble Decor is one of the most reputed wholesale & retail dealers of premium flooring products in South India. We are one of the very few dealers in Coimbatore who deals with the widest range of super premium flooring products like Imported Marble, Imported Granite, Indian Marble, Indian Granite, Sandstone, Quartz, Natural Stone, Premium Thin Tiless, Engineered Marble and etc.,
                                        </p><br>
                                        <h4>Vignesh Kumar - Proprietor</h4>
                                    </div>
                                    <div class="btn-wrapper style2 wow fadeInUp mt-3" data-wow-delay=".5s">
                                        <a href="about.php" class="theme-btn style3">
                                            READ MORE
                                            <svg xmlns="http://www.w3.org/2000/svg" width="41" height="26" viewBox="0 0 41 26" fill="none">
                                                <rect width="1" height="26" fill="#2B1E16"></rect>
                                                <path
                                                    d="M40.7071 13.7071C41.0976 13.3166 41.0976 12.6834 40.7071 12.2929L34.3431 5.92893C33.9526 5.53841 33.3195 5.53841 32.9289 5.92893C32.5384 6.31946 32.5384 6.95262 32.9289 7.34315L38.5858 13L32.9289 18.6569C32.5384 19.0474 32.5384 19.6805 32.9289 20.0711C33.3195 20.4616 33.9526 20.4616 34.3431 20.0711L40.7071 13.7071ZM15 14H40V12H15V14Z"
                                                    fill="#2B1E16"
                                                ></path>
                                            </svg>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Service Section    S T A R T -->
        <section class="service-section section-padding position-relative fix" data-bg-src="assets/images/bg/serviceBg1_1.jpg">
            <div class="container">
                <div class="row d-flex align-items-end mb-50">
                    <div class="col-xl-6">
                        <div class="section-title text-start">
                            <div class="subtitle text-start text-white wow fadeInUp" data-wow-delay=".5s"><img class="me-1" src="assets/images/shape/titleShapeWhite1_1.png" alt="icon" /> OUR PRODUCTS</div>
                            <h2 class="text-white text-start mt-15 wow fadeInUp" data-wow-delay=".3s">Marble Decor</h2>
                        </div>
                    </div>
                    <div class="col-xl-6 d-flex mt-4 mt-xl-0 justify-content-start justify-content-xl-end">
                        <div class="slider-arrow-btn text-end wow fadeInUp" data-wow-delay=".9s">
                            <button data-slider-prev="#serviceSliderOne" class="slider-arrow style1"><i class="fa-solid fa-arrow-left-long"></i></button>
                            <button data-slider-next="#serviceSliderOne" class="slider-arrow style1 slider-next"><i class="fa-solid fa-arrow-right-long"></i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="service-container-wrapper style1">
                <div class="container">
                    <div class="slider-area serviceSliderOne">
                        <div
                            class="swiper gt-slider"
                            id="serviceSliderOne"
                            data-slider-options='{"loop": true,"breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":1,"centeredSlides":true},"768":{"slidesPerView":1},"1025":{"slidesPerView":3},"1500":{"slidesPerView":3}}}'
                        >
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <div class="service-card style1 img-custom-anim-left wow fadeInUp" data-wow-delay=".3s">
                                        <div class="icon">
                                            <img src="assets/images/icon/serviceCardIcon1_1.svg" alt="icon" />
                                        </div>
                                        <h3>
                                            <a href="products.php?data=interior"> Interior </a>
                                        </h3>
                                        <div class="thumb">
                                            <img src="assets/img/interior/1.png" alt="thumb" />
                                        </div>
                                        <div class="link-btn style1">
                                            <a href="products.php?data=interior">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="16" viewBox="0 0 26 16" fill="none">
                                                    <path
                                                        d="M25.7071 8.70711C26.0976 8.31658 26.0976 7.68342 25.7071 7.29289L19.3431 0.928932C18.9526 0.538408 18.3195 0.538408 17.9289 0.928932C17.5384 1.31946 17.5384 1.95262 17.9289 2.34315L23.5858 8L17.9289 13.6569C17.5384 14.0474 17.5384 14.6805 17.9289 15.0711C18.3195 15.4616 18.9526 15.4616 19.3431 15.0711L25.7071 8.70711ZM0 9H25V7H0V9Z"
                                                        fill="#C7844F"
                                                    />
                                                </svg>
                                            </a>
                                        </div>
                                        <div class="shape1"><img src="assets/images/shape/serviceCardShape1_1.png" alt="shape" /></div>

                                        <div class="shape2"><img src="assets/images/shape/serviceCardShape1_2.png" alt="shape" /></div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="service-card style1 img-custom-anim-top wow fadeInUp" data-wow-delay=".5s">
                                        <div class="icon">
                                            <img src="assets/images/icon/serviceCardIcon1_3.svg" alt="icon" />
                                        </div>
                                        <h3>
                                            <a href="products.php?data=tiles"> Tiles </a>
                                        </h3>
                                        <div class="thumb">
                                            <img src="assets/img/tiles/1.png" alt="thumb" />
                                        </div>
                                        <div class="link-btn style1">
                                            <a href="products.php?data=tiles">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="16" viewBox="0 0 26 16" fill="none">
                                                    <path
                                                        d="M25.7071 8.70711C26.0976 8.31658 26.0976 7.68342 25.7071 7.29289L19.3431 0.928932C18.9526 0.538408 18.3195 0.538408 17.9289 0.928932C17.5384 1.31946 17.5384 1.95262 17.9289 2.34315L23.5858 8L17.9289 13.6569C17.5384 14.0474 17.5384 14.6805 17.9289 15.0711C18.3195 15.4616 18.9526 15.4616 19.3431 15.0711L25.7071 8.70711ZM0 9H25V7H0V9Z"
                                                        fill="#C7844F"
                                                    />
                                                </svg>
                                            </a>
                                        </div>
                                        <div class="shape1"><img src="assets/images/shape/serviceCardShape1_1.png" alt="shape" /></div>

                                        <div class="shape2"><img src="assets/images/shape/serviceCardShape1_2.png" alt="shape" /></div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="service-card style1 img-custom-anim-right wow fadeInUp" data-wow-delay=".8s">
                                        <div class="icon">
                                            <img src="assets/images/icon/serviceCardIcon1_2.svg" alt="icon" />
                                        </div>
                                        <h3>
                                            <a href="products.php?data=granite"> Granite </a>
                                        </h3>
                                        <div class="thumb">
                                            <img src="assets/img/granite/2.png" alt="thumb" />
                                        </div>
                                        <div class="link-btn style1">
                                            <a href="products.php?data=granite">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="16" viewBox="0 0 26 16" fill="none">
                                                    <path
                                                        d="M25.7071 8.70711C26.0976 8.31658 26.0976 7.68342 25.7071 7.29289L19.3431 0.928932C18.9526 0.538408 18.3195 0.538408 17.9289 0.928932C17.5384 1.31946 17.5384 1.95262 17.9289 2.34315L23.5858 8L17.9289 13.6569C17.5384 14.0474 17.5384 14.6805 17.9289 15.0711C18.3195 15.4616 18.9526 15.4616 19.3431 15.0711L25.7071 8.70711ZM0 9H25V7H0V9Z"
                                                        fill="#C7844F"
                                                    />
                                                </svg>
                                            </a>
                                        </div>
                                        <div class="shape1"><img src="assets/images/shape/serviceCardShape1_1.png" alt="shape" /></div>

                                        <div class="shape2"><img src="assets/images/shape/serviceCardShape1_2.png" alt="shape" /></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Offer Section    S T A R T -->
        <!-- <section class="offer-section">
            <div class="offer-container-wrapper style1 section-padding fix">
                <div class="shape"><img src="assets/images/shape/offerShape1_1.png" alt="shape" /></div>
                <div class="container">
                    <div class="section-title text-center mb-50 mxw-660 mx-auto">
                        <div class="subtitle text-center wow fadeInUp" data-wow-delay=".5s">
                            <img class="me-1" src="assets/images/shape/titleShape1_1.png" alt="icon" /> OUR SERVICES <img class="ms-1" src="assets/images/shape/titleShape1_2.png" alt="icon" />
                        </div>
                        <h2 class="text-center mt-15 wow fadeInUp" data-wow-delay=".3s">Marble Decor</h2>
                    </div>
                    <div class="slider-area offerSliderOne">
                        <div
                            class="swiper gt-slider"
                            id="offerSliderOne"
                            data-slider-options='{"loop": true,
                        "spaceBetween": 1, "breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":1,"centeredSlides":true},"768":{"slidesPerView":1},"992":{"slidesPerView":3},"1200":{"slidesPerView":4}}}'
                        >
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <div class="offer-card style1 img-custom-anim-left wow fadeInUp" data-wow-delay=".3s">
                                        <div class="bg"><img src="assets/images/offer/offerCardBg1_1.jpg" alt="bg" /></div>
                                        <div class="content">
                                            <div class="icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="none">
                                                    <g clip-path="url(#clip0_46_154)">
                                                        <path
                                                            opacity="0.96"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M14.8047 -0.0390625C22.9037 -0.0390625 31.0026 -0.0390625 39.1016 -0.0390625C39.4662 0.169271 39.7526 0.455729 39.9609 0.820312C39.9609 5.50781 39.9609 10.1953 39.9609 14.8828C39.5832 15.2958 39.2055 15.2958 38.8281 14.8828C38.8021 10.3776 38.776 5.8724 38.75 1.36719C38.7109 1.27604 38.6459 1.21094 38.5547 1.17188C30.7943 1.11979 23.0338 1.11979 15.2734 1.17188C15.1184 3.06808 15.0663 4.98214 15.1172 6.91406C17.4351 6.90105 19.7527 6.91406 22.0703 6.95312C22.3916 7.2273 22.4567 7.55282 22.2656 7.92969C22.1741 8.03852 22.057 8.10367 21.9141 8.125C17.3308 8.16406 12.7475 8.17711 8.16406 8.16406C8.16406 10.0651 8.16406 11.9662 8.16406 13.8672C13.7891 13.8541 19.4141 13.8672 25.0391 13.9062C25.5209 14.0755 25.8463 14.401 26.0156 14.8828C26.0547 20.5077 26.0677 26.1327 26.0547 31.7578C27.9557 31.7578 29.8568 31.7578 31.7578 31.7578C31.7448 31.0282 31.7578 30.299 31.7969 29.5703C32.1547 28.9791 32.5453 28.953 32.9688 29.4922C33.0209 30.3516 33.0209 31.2109 32.9688 32.0703C32.8255 32.526 32.526 32.8255 32.0703 32.9688C30.0652 33.0078 28.0601 33.0209 26.0547 33.0078C26.0677 34.9872 26.0547 36.9663 26.0156 38.9453C25.8893 39.4486 25.5898 39.7871 25.1172 39.9609C17.0182 39.9609 8.9193 39.9609 0.820312 39.9609C0.455729 39.7526 0.169271 39.4662 -0.0390625 39.1016C-0.0390625 31.0026 -0.0390625 22.9037 -0.0390625 14.8047C0.134727 14.332 0.473269 14.0326 0.976562 13.9062C2.95555 13.8672 4.93473 13.8541 6.91406 13.8672C6.90105 11.8618 6.91406 9.85664 6.95312 7.85156C7.09635 7.39584 7.39584 7.09635 7.85156 6.95312C9.85664 6.91406 11.8618 6.90105 13.8672 6.91406C13.8541 4.93473 13.8672 2.95555 13.9062 0.976562C14.0326 0.473269 14.332 0.134727 14.8047 -0.0390625ZM2.14844 15.1953C3.09841 15.1047 4.06196 15.0916 5.03906 15.1562C5.35156 15.4688 5.66406 15.7812 5.97656 16.0938C6.56352 16.4557 6.95415 16.3124 7.14844 15.6641C7.10195 15.4799 7.02382 15.3107 6.91406 15.1562C7.87758 15.1041 8.84117 15.1041 9.80469 15.1562C10.1432 15.4948 10.4818 15.8334 10.8203 16.1719C11.5308 16.4246 11.8563 16.1772 11.7969 15.4297C11.7605 15.3179 11.6954 15.2268 11.6016 15.1562C12.5651 15.1041 13.5287 15.1041 14.4922 15.1562C14.8047 15.4688 15.1172 15.7812 15.4297 16.0938C16.0166 16.4557 16.4073 16.3124 16.6016 15.6641C16.5551 15.4799 16.477 15.3107 16.3672 15.1562C17.3307 15.1041 18.2943 15.1041 19.2578 15.1562C19.5963 15.4948 19.9349 15.8334 20.2734 16.1719C20.9839 16.4246 21.3095 16.1772 21.25 15.4297C21.2137 15.3179 21.1485 15.2268 21.0547 15.1562C22.2975 15.0919 23.5345 15.1049 24.7656 15.1953C24.8177 16.4193 24.8177 17.6432 24.7656 18.8672C24.2049 18.4705 23.8013 18.5877 23.5547 19.2188C23.6011 19.4367 23.6923 19.632 23.8281 19.8047C24.1406 20.1172 24.4531 20.4297 24.7656 20.7422C24.8177 21.7057 24.8177 22.6693 24.7656 23.6328C24.1927 23.1479 23.7891 23.2651 23.5547 23.9844C23.5938 24.1016 23.6328 24.2188 23.6719 24.3359C24.0365 24.7005 24.401 25.0651 24.7656 25.4297C24.8177 26.3932 24.8177 27.3568 24.7656 28.3203C24.401 28.0078 24.0365 28.0078 23.6719 28.3203C23.5156 28.5547 23.5156 28.7891 23.6719 29.0234C24.0365 29.388 24.401 29.7526 24.7656 30.1172C24.8177 31.1068 24.8177 32.0963 24.7656 33.0859C24.1927 32.601 23.7891 32.7182 23.5547 33.4375C23.5938 33.5547 23.6328 33.6719 23.6719 33.7891C24.0365 34.1537 24.401 34.5182 24.7656 34.8828C24.8177 35.8463 24.8177 36.8099 24.7656 37.7734C24.401 37.4609 24.0365 37.4609 23.6719 37.7734C23.5071 38.1652 23.5982 38.4906 23.9453 38.75C22.9557 38.8021 21.9662 38.8021 20.9766 38.75C20.612 38.3854 20.2474 38.0209 19.8828 37.6562C19.1723 37.4035 18.8468 37.6509 18.9062 38.3984C18.9676 38.538 19.0587 38.6552 19.1797 38.75C18.2162 38.8021 17.2526 38.8021 16.2891 38.75C15.9245 38.3854 15.5599 38.0209 15.1953 37.6562C14.3823 37.3773 14.0568 37.6507 14.2188 38.4766C14.3099 38.5677 14.401 38.6588 14.4922 38.75C13.5026 38.8021 12.513 38.8021 11.5234 38.75C11.1588 38.3854 10.7943 38.0209 10.4297 37.6562C9.71922 37.4035 9.39367 37.6509 9.45312 38.3984C9.51445 38.538 9.60555 38.6552 9.72656 38.75C8.76305 38.8021 7.79948 38.8021 6.83594 38.75C6.47135 38.3854 6.10677 38.0209 5.74219 37.6562C5.16563 37.3848 4.80105 37.554 4.64844 38.1641C4.69965 38.4109 4.82985 38.6062 5.03906 38.75C3.8151 38.8021 2.59115 38.8021 1.36719 38.75C1.30405 38.7259 1.25198 38.6869 1.21094 38.6328C1.121 37.3862 1.10798 36.1362 1.17188 34.8828C1.49059 35.3042 1.85518 35.3563 2.26562 35.0391C2.42188 34.7526 2.42188 34.4662 2.26562 34.1797C1.90104 33.8151 1.53646 33.4505 1.17188 33.0859C1.11979 32.1224 1.11979 31.1588 1.17188 30.1953C1.5625 30.612 1.95312 30.612 2.34375 30.1953C2.40548 29.9505 2.37944 29.7161 2.26562 29.4922C1.90104 29.1276 1.53646 28.763 1.17188 28.3984C1.11979 27.4088 1.11979 26.4193 1.17188 25.4297C1.49059 25.8511 1.85518 25.9031 2.26562 25.5859C2.42188 25.2995 2.42188 25.013 2.26562 24.7266C1.90104 24.362 1.53646 23.9974 1.17188 23.6328C1.11979 22.6693 1.11979 21.7057 1.17188 20.7422C1.56841 21.1528 1.95903 21.1528 2.34375 20.7422C2.40548 20.4973 2.37944 20.263 2.26562 20.0391C1.90104 19.6745 1.53646 19.3099 1.17188 18.9453C1.11979 17.9557 1.11979 16.9662 1.17188 15.9766C1.56841 16.3872 1.95903 16.3872 2.34375 15.9766C2.43255 15.667 2.36745 15.4066 2.14844 15.1953Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.945"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M39.9609 16.8359C39.9609 19.5963 39.9609 22.3568 39.9609 25.1172C39.7871 25.5898 39.4486 25.8893 38.9453 26.0156C36.9663 26.0547 34.9872 26.0677 33.0078 26.0547C33.0208 26.5241 33.0077 26.9929 32.9687 27.4609C32.7016 27.7932 32.376 27.8584 31.9922 27.6563C31.8984 27.5857 31.8332 27.4946 31.7969 27.3828C31.7709 21.0026 31.7448 14.6224 31.7187 8.24219C29.2113 8.17742 26.6983 8.13836 24.1797 8.125C23.7423 7.91446 23.6252 7.58893 23.8281 7.14844C23.8987 7.05458 23.9898 6.98947 24.1016 6.95313C26.7318 6.90104 29.3619 6.90104 31.9922 6.95313C32.474 7.1224 32.7994 7.44792 32.9687 7.92969C33.0078 13.5546 33.0209 19.1796 33.0078 24.8047C34.9095 24.8307 36.8106 24.8047 38.7109 24.7266C38.7755 22.0996 38.8145 19.4694 38.8281 16.8359C39.2054 16.4244 39.583 16.4244 39.9609 16.8359Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.899"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M3.86719 16.2891C4.59206 16.2012 4.8655 16.5137 4.6875 17.2266C4.23177 17.6823 3.77604 18.138 3.32031 18.5937C2.5 18.8151 2.20052 18.5156 2.42187 17.6953C2.89546 17.2086 3.37723 16.7398 3.86719 16.2891Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.903"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M8.55468 16.2891C9.40601 16.2472 9.65335 16.6118 9.29687 17.3828C8.86163 17.8705 8.37984 18.3002 7.85155 18.6719C7.21032 18.7072 6.96292 18.4077 7.10937 17.7734C7.60698 17.2889 8.08874 16.7941 8.55468 16.2891Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.898"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M13.3203 16.2891C14.0452 16.2012 14.3186 16.5137 14.1406 17.2266C13.6849 17.6823 13.2291 18.138 12.7734 18.5937C11.9531 18.8151 11.6537 18.5156 11.875 17.6953C12.3486 17.2086 12.8304 16.7398 13.3203 16.2891Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.879"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M18.0078 16.2891C18.8591 16.2472 19.1065 16.6118 18.75 17.3828C18.3148 17.8705 17.833 18.3002 17.3047 18.6719C16.6634 18.7072 16.416 18.4077 16.5625 17.7734C17.0076 17.2372 17.4894 16.7424 18.0078 16.2891Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.899"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M22.6953 16.2891C23.5274 16.1835 23.8009 16.522 23.5156 17.3047C23.0859 17.7344 22.6563 18.1641 22.2266 18.5938C21.4063 18.8151 21.1068 18.5156 21.3281 17.6953C21.7997 17.2368 22.2555 16.768 22.6953 16.2891Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.895"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M5.03906 18.6328C5.28509 18.6102 5.51946 18.6493 5.74218 18.75C6.14583 19.1537 6.54947 19.5573 6.95312 19.9609C7.31026 20.7387 7.06286 21.0903 6.21093 21.0156C5.72916 20.5338 5.24739 20.0521 4.76562 19.5703C4.62714 19.1914 4.71829 18.8789 5.03906 18.6328Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.898"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M9.72657 18.6328C9.97258 18.6102 10.207 18.6493 10.4297 18.75C10.8594 19.1797 11.2891 19.6094 11.7188 20.0391C11.9209 20.4229 11.8557 20.7484 11.5234 21.0156C11.2786 21.0773 11.0442 21.0513 10.8203 20.9375C10.3906 20.5078 9.96094 20.0781 9.53126 19.6484C9.34422 19.2599 9.40938 18.9214 9.72657 18.6328Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.896"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M14.4922 18.6328C14.7827 18.5939 15.0432 18.6591 15.2734 18.8281C15.651 19.2057 16.0287 19.5834 16.4062 19.9609C16.7634 20.7388 16.516 21.0903 15.6641 21.0156C15.1823 20.5338 14.7005 20.0521 14.2187 19.5703C14.0802 19.1914 14.1714 18.8789 14.4922 18.6328Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.9"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M19.1797 18.6328C19.4257 18.6102 19.6601 18.6493 19.8828 18.75C20.3125 19.1797 20.7422 19.6094 21.1719 20.0391C21.4506 20.6093 21.2813 20.9478 20.6641 21.0547C20.5235 21.0487 20.3933 21.0096 20.2734 20.9375C19.8438 20.5078 19.4141 20.0781 18.9844 19.6484C18.7973 19.2599 18.8625 18.9214 19.1797 18.6328Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.903"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M3.94531 20.9766C4.69594 21.0121 4.91729 21.3767 4.60937 22.0703C4.17724 22.5286 3.7215 22.9583 3.24218 23.3594C2.4993 23.4762 2.22586 23.1766 2.42187 22.4609C2.92149 21.9482 3.42931 21.4534 3.94531 20.9766Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.896"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M8.63281 20.9766C9.37757 20.9563 9.62492 21.2948 9.37499 21.9922C8.94531 22.4219 8.51562 22.8516 8.08593 23.2813C7.21353 23.5547 6.91406 23.2552 7.18749 22.3828C7.66108 21.8961 8.14288 21.4273 8.63281 20.9766Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.879"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M13.3984 20.9766C14.0387 20.9788 14.2862 21.2913 14.1406 21.9141C13.7109 22.4479 13.2291 22.9297 12.6953 23.3594C11.843 23.4392 11.5956 23.0877 11.9531 22.3047C12.4034 21.8149 12.8851 21.3722 13.3984 20.9766Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.897"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M18.0859 20.9766C18.8307 20.9563 19.078 21.2948 18.8281 21.9922C18.3984 22.4219 17.9687 22.8516 17.5391 23.2813C16.6666 23.5547 16.3672 23.2552 16.6406 22.3828C17.1142 21.8961 17.596 21.4273 18.0859 20.9766Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.879"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M22.8516 20.9766C23.4919 20.9788 23.7393 21.2913 23.5937 21.9141C23.1641 22.4479 22.6823 22.9297 22.1484 23.3594C21.2961 23.4392 21.0487 23.0877 21.4062 22.3047C21.8565 21.8149 22.3382 21.3722 22.8516 20.9766Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.897"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M5.19531 23.3203C5.35658 23.3349 5.51283 23.374 5.66406 23.4375C6.11979 23.8932 6.57552 24.349 7.03125 24.8047C7.239 25.3267 7.06973 25.6652 6.52344 25.8203C6.39726 25.7692 6.26704 25.7302 6.13281 25.7031C5.67708 25.2474 5.22135 24.7916 4.76562 24.3359C4.58292 23.8546 4.72615 23.5161 5.19531 23.3203Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.895"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M9.88281 23.3203C10.1113 23.3172 10.3196 23.3823 10.5078 23.5156C10.9115 23.9193 11.3151 24.3229 11.7188 24.7266C11.9977 25.5396 11.7243 25.8651 10.8984 25.7031C10.4166 25.2213 9.93492 24.7396 9.45313 24.2578C9.32758 23.8063 9.47086 23.4938 9.88281 23.3203Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.895"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M14.5703 23.3203C14.7599 23.3221 14.9422 23.3612 15.1172 23.4375C15.5729 23.8932 16.0287 24.349 16.4844 24.8047C16.6804 25.3227 16.5111 25.6613 15.9766 25.8203C15.8504 25.7692 15.7202 25.7302 15.5859 25.7031C15.1302 25.2474 14.6745 24.7916 14.2188 24.3359C14.0484 23.8966 14.1656 23.5581 14.5703 23.3203Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.896"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M19.3359 23.3203C19.5645 23.3172 19.7727 23.3823 19.9609 23.5156C20.3385 23.8932 20.7162 24.2709 21.0938 24.6484C21.4558 25.2312 21.3126 25.6218 20.6641 25.8203C20.5629 25.7736 20.4588 25.7345 20.3516 25.7031C19.8698 25.2213 19.388 24.7396 18.9063 24.2578C18.7807 23.8063 18.924 23.4938 19.3359 23.3203Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.9"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M3.78907 25.7422C4.55704 25.6116 4.85652 25.9241 4.68751 26.6797C4.23178 27.1354 3.77604 27.5912 3.32032 28.0469C2.64274 28.2616 2.31722 28.0141 2.34376 27.3047C2.81287 26.7705 3.29464 26.2497 3.78907 25.7422Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.879"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M8.55468 25.7422C9.40601 25.7003 9.65335 26.0649 9.29687 26.8359C8.86163 27.3236 8.37984 27.7533 7.85155 28.125C7.21032 28.1603 6.96292 27.8609 7.10937 27.2266C7.55455 26.6903 8.03632 26.1955 8.55468 25.7422Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.897"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M13.2422 25.7422C14.0102 25.6116 14.3096 25.9241 14.1406 26.6797C13.6849 27.1354 13.2291 27.5912 12.7734 28.0469C11.9531 28.2682 11.6537 27.9687 11.875 27.1484C12.3466 26.6899 12.8023 26.2212 13.2422 25.7422Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.879"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M18.0078 25.7422C18.8591 25.7003 19.1065 26.0649 18.75 26.8359C18.3148 27.3236 17.833 27.7533 17.3047 28.125C16.6634 28.1603 16.416 27.8609 16.5625 27.2266C17.0076 26.6903 17.4894 26.1955 18.0078 25.7422Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.898"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M22.6953 25.7422C23.5274 25.6366 23.8009 25.9752 23.5156 26.7578C23.0859 27.1875 22.6563 27.6172 22.2266 28.0469C21.4063 28.2682 21.1068 27.9688 21.3281 27.1484C21.7997 26.6899 22.2555 26.2212 22.6953 25.7422Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.895"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M5.03906 28.0859C5.28509 28.0634 5.51946 28.1024 5.74218 28.2031C6.14583 28.6068 6.54947 29.0104 6.95312 29.4141C7.31026 30.1919 7.06286 30.5434 6.21093 30.4687C5.72916 29.987 5.24739 29.5052 4.76562 29.0234C4.62714 28.6445 4.71829 28.332 5.03906 28.0859Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.9"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M9.72657 28.0859C9.97258 28.0634 10.207 28.1024 10.4297 28.2031C10.8594 28.6328 11.2891 29.0625 11.7188 29.4922C11.9975 30.0624 11.8282 30.4009 11.2109 30.5078C11.0704 30.5018 10.9402 30.4627 10.8203 30.3906C10.3906 29.9609 9.96094 29.5312 9.53126 29.1016C9.34422 28.713 9.40938 28.3745 9.72657 28.0859Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.897"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M14.4922 28.0859C14.7382 28.0634 14.9726 28.1024 15.1953 28.2031C15.599 28.6068 16.0026 29.0104 16.4062 29.4141C16.6707 29.7498 16.6577 30.0754 16.3672 30.3906C16.1433 30.5045 15.9089 30.5305 15.6641 30.4688C15.1823 29.987 14.7005 29.5052 14.2187 29.0234C14.0802 28.6445 14.1714 28.332 14.4922 28.0859Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.898"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M19.1797 28.0859C19.4257 28.0634 19.6601 28.1024 19.8828 28.2031C20.3125 28.6328 20.7422 29.0625 21.1719 29.4922C21.4506 30.0624 21.2813 30.4009 20.6641 30.5078C20.5235 30.5018 20.3933 30.4627 20.2734 30.3906C19.8438 29.9609 19.4141 29.5312 18.9844 29.1016C18.7858 28.7061 18.8509 28.3676 19.1797 28.0859Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.879"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M3.94532 30.4297C4.58567 30.432 4.83306 30.7445 4.6875 31.3672C4.25782 31.901 3.77604 32.3828 3.24219 32.8125C2.38987 32.8923 2.14248 32.5408 2.5 31.7578C2.95022 31.268 3.43199 30.8253 3.94532 30.4297Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.897"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M8.63281 30.4297C9.37757 30.4095 9.62492 30.748 9.37499 31.4453C8.94531 31.875 8.51562 32.3047 8.08593 32.7344C7.21353 33.0078 6.91406 32.7084 7.18749 31.8359C7.66108 31.3492 8.14288 30.8805 8.63281 30.4297Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.879"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M13.3984 30.4297C14.0387 30.432 14.2862 30.7445 14.1406 31.3672C13.7109 31.901 13.2291 32.3828 12.6953 32.8125C11.843 32.8923 11.5956 32.5408 11.9531 31.7578C12.4034 31.268 12.8851 30.8253 13.3984 30.4297Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.895"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M18.0859 30.4297C18.8307 30.4095 19.0781 30.748 18.8281 31.4453C18.3984 31.875 17.9688 32.3047 17.5391 32.7344C16.7438 33.0203 16.4183 32.7469 16.5625 31.9141C17.0621 31.4013 17.5699 30.9065 18.0859 30.4297Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.903"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M22.8516 30.4297C23.4919 30.432 23.7393 30.7445 23.5937 31.3672C23.1119 31.849 22.6302 32.3307 22.1484 32.8125C21.2961 32.8923 21.0487 32.5408 21.4062 31.7578C21.8565 31.268 22.3382 30.8253 22.8516 30.4297Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.898"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M5.11719 32.7734C5.30678 32.7752 5.48907 32.8143 5.66407 32.8906C6.11979 33.3463 6.57553 33.8021 7.03125 34.2578C7.2398 34.8041 7.05751 35.1427 6.48438 35.2734C6.3425 35.2087 6.19927 35.1435 6.05469 35.0781C5.625 34.6484 5.19532 34.2188 4.76563 33.7891C4.5949 33.3508 4.71208 33.0122 5.11719 32.7734Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.895"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M9.88281 32.7734C10.1113 32.7703 10.3196 32.8354 10.5078 32.9688C10.9115 33.3724 11.3151 33.776 11.7188 34.1797C11.9977 34.9927 11.7243 35.3182 10.8984 35.1563C10.4166 34.6745 9.93492 34.1927 9.45313 33.7109C9.32758 33.2595 9.47086 32.947 9.88281 32.7734Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.897"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M14.5703 32.7734C14.7599 32.7752 14.9422 32.8143 15.1172 32.8906C15.5729 33.3463 16.0287 33.8021 16.4844 34.2578C16.6849 34.8017 16.5027 35.1403 15.9375 35.2734C15.8282 35.2166 15.711 35.1776 15.5859 35.1562C15.1302 34.7005 14.6745 34.2448 14.2188 33.7891C14.0484 33.3498 14.1656 33.0112 14.5703 32.7734Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.895"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M19.3359 32.7734C19.5645 32.7703 19.7727 32.8354 19.9609 32.9688C20.3646 33.3724 20.7682 33.776 21.1719 34.1797C21.4509 34.9927 21.1774 35.3182 20.3516 35.1563C19.8698 34.6745 19.388 34.1927 18.9063 33.7109C18.7807 33.2595 18.924 32.947 19.3359 32.7734Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.9"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M3.78907 35.1953C4.55704 35.0648 4.85652 35.3773 4.68751 36.1328C4.23178 36.5885 3.77604 37.0443 3.32032 37.5C2.64274 37.7147 2.31722 37.4673 2.34376 36.7578C2.81287 36.2237 3.29464 35.7028 3.78907 35.1953Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.878"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M8.55468 35.1953C9.40601 35.1534 9.65335 35.518 9.29687 36.2891C8.86163 36.7767 8.37984 37.2064 7.85155 37.5781C7.21032 37.6134 6.96292 37.314 7.10937 36.6797C7.55455 36.1434 8.03632 35.6487 8.55468 35.1953Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.901"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M13.2422 35.1953C13.9681 35.0548 14.2675 35.3412 14.1406 36.0547C13.7134 36.5601 13.2577 37.0419 12.7734 37.5C12.0959 37.7147 11.7703 37.4673 11.7969 36.7578C12.266 36.2237 12.7477 35.7028 13.2422 35.1953Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.901"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M18.0078 35.1953C18.6417 35.0876 18.9412 35.348 18.9063 35.9766C18.4531 36.508 17.9713 37.0158 17.4609 37.5C16.7452 37.696 16.4457 37.4226 16.5625 36.6797C17.0077 36.1434 17.4895 35.6487 18.0078 35.1953Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.9"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M22.6953 35.1953C23.5274 35.0898 23.8009 35.4283 23.5156 36.2109C23.0859 36.6406 22.6563 37.0703 22.2266 37.5C21.4049 37.7201 21.1055 37.4205 21.3281 36.6016C21.7997 36.143 22.2555 35.6743 22.6953 35.1953Z"
                                                            fill="white"
                                                        />
                                                    </g>
                                                    <defs>
                                                        <clipPath id="clip0_46_154">
                                                            <rect width="40" height="40" fill="white" />
                                                        </clipPath>
                                                    </defs>
                                                </svg>
                                            </div>
                                            <h3>
                                                <a href="service-details.php">Modern Tiless</a>
                                            </h3>
                                            <p class="text">There are many flo variations of passages of atitl Lorem Ipsum available, but thedw,</p>
                                            <ul class="checklist style1">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22" fill="none">
                                                        <g clip-path="url(#clip0_44_5)">
                                                            <path
                                                                opacity="0.964"
                                                                fill-rule="evenodd"
                                                                clip-rule="evenodd"
                                                                d="M10.7422 0.242159C11.2869 0.214254 11.7869 0.347065 12.2422 0.640597C12.8625 1.12005 13.4406 1.6513 13.9766 2.23435C14.2725 2.49163 14.6163 2.64788 15.0078 2.7031C15.7898 2.74525 16.5711 2.79212 17.3516 2.84372C18.2812 3.08591 18.8672 3.67185 19.1094 4.60153C19.1672 5.31844 19.1984 6.03717 19.2031 6.75778C19.1858 7.22025 19.3265 7.62652 19.625 7.97653C20.2393 8.54367 20.8018 9.15305 21.3125 9.80466C21.8012 10.5826 21.8324 11.3795 21.4063 12.1953C20.8975 12.8919 20.3194 13.5325 19.6719 14.1172C19.3311 14.4867 19.1749 14.9242 19.2031 15.4297C19.1875 16.0703 19.1719 16.7109 19.1563 17.3515C18.9785 18.4668 18.33 19.1153 17.2109 19.2968C16.4171 19.3876 15.6202 19.4345 14.8203 19.4375C14.6558 19.4573 14.4996 19.5041 14.3516 19.5781C13.978 19.9048 13.6186 20.2485 13.2734 20.6093C12.8053 21.0619 12.274 21.4212 11.6797 21.6875C10.9165 21.9067 10.2134 21.7817 9.57032 21.3125C8.97655 20.7812 8.41405 20.2187 7.88282 19.625C7.58118 19.3415 7.22183 19.2009 6.80469 19.2031C3.74966 19.6167 2.39809 18.2964 2.75001 15.2422C2.77494 14.7632 2.63431 14.3414 2.32813 13.9765C1.78125 13.4922 1.26563 12.9765 0.781256 12.4297C0.125105 11.5554 0.0782299 10.6492 0.640631 9.71091C1.12008 9.09061 1.65134 8.51246 2.23438 7.97653C2.56328 7.56816 2.73516 7.09941 2.75001 6.57028C2.75405 5.88066 2.7853 5.19314 2.84376 4.50778C3.06515 3.58325 3.63546 2.99732 4.55469 2.74997C5.33277 2.65826 6.11404 2.61139 6.89844 2.60935C7.21921 2.5662 7.51612 2.45682 7.78907 2.28122C8.38457 1.73249 8.99394 1.20124 9.61719 0.687472C9.97012 0.468579 10.3451 0.32014 10.7422 0.242159ZM10.8359 1.69528C11.0475 1.69941 11.235 1.76972 11.3984 1.90622C11.9609 2.43747 12.5234 2.96872 13.0859 3.49997C13.5672 3.88894 14.1141 4.13897 14.7266 4.24997C15.3818 4.29994 16.0381 4.33121 16.6953 4.34372C17.0189 4.36214 17.2767 4.49494 17.4688 4.74216C17.5348 4.90889 17.5816 5.08078 17.6094 5.25778C17.6211 5.94628 17.6524 6.6338 17.7031 7.32028C17.7838 7.78121 17.9556 8.20308 18.2188 8.58591C18.7955 9.20953 19.3892 9.81891 20 10.414C20.1238 10.5835 20.2097 10.771 20.2578 10.9765C20.1611 11.2169 20.0282 11.4357 19.8594 11.6328C19.3424 12.1342 18.8423 12.6498 18.3594 13.1797C18.0054 13.6004 17.7866 14.0848 17.7031 14.6328C17.6524 15.3193 17.6211 16.0068 17.6094 16.6953C17.591 17.0188 17.4582 17.2766 17.2109 17.4687C17.0442 17.5347 16.8723 17.5816 16.6953 17.6093C16.0389 17.6378 15.3827 17.669 14.7266 17.7031C13.6811 17.8386 12.8764 18.3464 12.3125 19.2265C12.0534 19.4856 11.7956 19.7434 11.5391 20C11.3696 20.1238 11.1821 20.2097 10.9766 20.2578C10.7711 20.2097 10.5836 20.1238 10.4141 20C9.97396 19.6067 9.58335 19.1693 9.24219 18.6875C8.69929 18.1738 8.05869 17.8457 7.32032 17.7031C6.63374 17.6537 5.94623 17.6225 5.25782 17.6093C4.93429 17.5909 4.67648 17.4581 4.48438 17.2109C4.41838 17.0442 4.37151 16.8723 4.34376 16.6953C4.33199 16.0068 4.30077 15.3193 4.25001 14.6328C4.16938 14.1719 3.99754 13.75 3.73438 13.3672C3.15764 12.7435 2.56389 12.1342 1.95313 11.539C1.83569 11.3745 1.74975 11.1948 1.69532 11C1.78554 10.7493 1.91835 10.5228 2.09376 10.3203C2.57955 9.85017 3.0483 9.36577 3.50001 8.86716C3.88898 8.38594 4.13901 7.83905 4.25001 7.22653C4.30138 6.57136 4.33265 5.91511 4.34376 5.25778C4.36719 4.67185 4.67188 4.36716 5.25782 4.34372C5.89954 4.33224 6.54018 4.30097 7.17969 4.24997C7.80013 4.12721 8.36263 3.87722 8.86719 3.49997C9.27229 3.11044 9.66294 2.70418 10.0391 2.28122C10.2746 2.03912 10.5402 1.84381 10.8359 1.69528Z"
                                                                fill="white"
                                                            />
                                                            <path
                                                                opacity="0.959"
                                                                fill-rule="evenodd"
                                                                clip-rule="evenodd"
                                                                d="M13.6953 7.69531C14.5874 7.6573 14.9077 8.06356 14.6562 8.91406C13.2354 10.6241 11.8057 12.3272 10.3672 14.0234C10.1639 14.1368 9.95298 14.2306 9.73436 14.3047C9.57573 14.2779 9.42728 14.2232 9.28905 14.1406C8.64062 13.5547 7.99216 12.9687 7.34373 12.3828C7.20944 12.0926 7.19378 11.7957 7.29686 11.4922C7.43561 11.2351 7.65437 11.1101 7.95311 11.1172C8.16203 11.1245 8.35736 11.1792 8.53905 11.2812C8.92187 11.6328 9.30466 11.9844 9.68748 12.3359C10.8594 10.9297 12.0312 9.52344 13.2031 8.11719C13.3486 7.94778 13.5126 7.80715 13.6953 7.69531Z"
                                                                fill="white"
                                                            />
                                                        </g>
                                                        <defs>
                                                            <clipPath id="clip0_44_5">
                                                                <rect width="22" height="22" fill="white" />
                                                            </clipPath>
                                                        </defs>
                                                    </svg>
                                                    More Expensive
                                                </li>
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22" fill="none">
                                                        <g clip-path="url(#clip0_44_6)">
                                                            <path
                                                                opacity="0.964"
                                                                fill-rule="evenodd"
                                                                clip-rule="evenodd"
                                                                d="M10.7422 0.242159C11.2869 0.214254 11.7869 0.347065 12.2422 0.640597C12.8625 1.12005 13.4406 1.6513 13.9766 2.23435C14.2725 2.49163 14.6163 2.64788 15.0078 2.7031C15.7898 2.74525 16.5711 2.79212 17.3516 2.84372C18.2812 3.08591 18.8672 3.67185 19.1094 4.60153C19.1672 5.31844 19.1984 6.03717 19.2031 6.75778C19.1858 7.22025 19.3265 7.62652 19.625 7.97653C20.2393 8.54367 20.8018 9.15305 21.3125 9.80466C21.8012 10.5826 21.8324 11.3795 21.4063 12.1953C20.8975 12.8919 20.3194 13.5325 19.6719 14.1172C19.3311 14.4867 19.1749 14.9242 19.2031 15.4297C19.1875 16.0703 19.1719 16.7109 19.1563 17.3515C18.9785 18.4668 18.33 19.1153 17.2109 19.2968C16.4171 19.3876 15.6202 19.4345 14.8203 19.4375C14.6558 19.4573 14.4996 19.5041 14.3516 19.5781C13.978 19.9048 13.6186 20.2485 13.2734 20.6093C12.8053 21.0619 12.274 21.4212 11.6797 21.6875C10.9165 21.9067 10.2134 21.7817 9.57032 21.3125C8.97655 20.7812 8.41405 20.2187 7.88282 19.625C7.58118 19.3415 7.22183 19.2009 6.80469 19.2031C3.74966 19.6167 2.39809 18.2964 2.75001 15.2422C2.77494 14.7632 2.63431 14.3414 2.32813 13.9765C1.78125 13.4922 1.26563 12.9765 0.781256 12.4297C0.125105 11.5554 0.0782299 10.6492 0.640631 9.71091C1.12008 9.09061 1.65134 8.51246 2.23438 7.97653C2.56328 7.56816 2.73516 7.09941 2.75001 6.57028C2.75405 5.88066 2.7853 5.19314 2.84376 4.50778C3.06515 3.58325 3.63546 2.99732 4.55469 2.74997C5.33277 2.65826 6.11404 2.61139 6.89844 2.60935C7.21921 2.5662 7.51612 2.45682 7.78907 2.28122C8.38457 1.73249 8.99394 1.20124 9.61719 0.687472C9.97012 0.468579 10.3451 0.32014 10.7422 0.242159ZM10.8359 1.69528C11.0475 1.69941 11.235 1.76972 11.3984 1.90622C11.9609 2.43747 12.5234 2.96872 13.0859 3.49997C13.5672 3.88894 14.1141 4.13897 14.7266 4.24997C15.3818 4.29994 16.0381 4.33121 16.6953 4.34372C17.0189 4.36214 17.2767 4.49494 17.4688 4.74216C17.5348 4.90889 17.5816 5.08078 17.6094 5.25778C17.6211 5.94628 17.6524 6.6338 17.7031 7.32028C17.7838 7.78121 17.9556 8.20308 18.2188 8.58591C18.7955 9.20953 19.3892 9.81891 20 10.414C20.1238 10.5835 20.2097 10.771 20.2578 10.9765C20.1611 11.2169 20.0282 11.4357 19.8594 11.6328C19.3424 12.1342 18.8423 12.6498 18.3594 13.1797C18.0054 13.6004 17.7866 14.0848 17.7031 14.6328C17.6524 15.3193 17.6211 16.0068 17.6094 16.6953C17.591 17.0188 17.4582 17.2766 17.2109 17.4687C17.0442 17.5347 16.8723 17.5816 16.6953 17.6093C16.0389 17.6378 15.3827 17.669 14.7266 17.7031C13.6811 17.8386 12.8764 18.3464 12.3125 19.2265C12.0534 19.4856 11.7956 19.7434 11.5391 20C11.3696 20.1238 11.1821 20.2097 10.9766 20.2578C10.7711 20.2097 10.5836 20.1238 10.4141 20C9.97396 19.6067 9.58335 19.1693 9.24219 18.6875C8.69929 18.1738 8.05869 17.8457 7.32032 17.7031C6.63374 17.6537 5.94623 17.6225 5.25782 17.6093C4.93429 17.5909 4.67648 17.4581 4.48438 17.2109C4.41838 17.0442 4.37151 16.8723 4.34376 16.6953C4.33199 16.0068 4.30077 15.3193 4.25001 14.6328C4.16938 14.1719 3.99754 13.75 3.73438 13.3672C3.15764 12.7435 2.56389 12.1342 1.95313 11.539C1.83569 11.3745 1.74975 11.1948 1.69532 11C1.78554 10.7493 1.91835 10.5228 2.09376 10.3203C2.57955 9.85017 3.0483 9.36577 3.50001 8.86716C3.88898 8.38594 4.13901 7.83905 4.25001 7.22653C4.30138 6.57136 4.33265 5.91511 4.34376 5.25778C4.36719 4.67185 4.67188 4.36716 5.25782 4.34372C5.89954 4.33224 6.54018 4.30097 7.17969 4.24997C7.80013 4.12721 8.36263 3.87722 8.86719 3.49997C9.27229 3.11044 9.66294 2.70418 10.0391 2.28122C10.2746 2.03912 10.5402 1.84381 10.8359 1.69528Z"
                                                                fill="white"
                                                            />
                                                            <path
                                                                opacity="0.959"
                                                                fill-rule="evenodd"
                                                                clip-rule="evenodd"
                                                                d="M13.6953 7.69531C14.5874 7.6573 14.9077 8.06356 14.6562 8.91406C13.2354 10.6241 11.8057 12.3272 10.3672 14.0234C10.1639 14.1368 9.95298 14.2306 9.73436 14.3047C9.57573 14.2779 9.42728 14.2232 9.28905 14.1406C8.64062 13.5547 7.99216 12.9687 7.34373 12.3828C7.20944 12.0926 7.19378 11.7957 7.29686 11.4922C7.43561 11.2351 7.65437 11.1101 7.95311 11.1172C8.16203 11.1245 8.35736 11.1792 8.53905 11.2812C8.92187 11.6328 9.30466 11.9844 9.68748 12.3359C10.8594 10.9297 12.0312 9.52344 13.2031 8.11719C13.3486 7.94778 13.5126 7.80715 13.6953 7.69531Z"
                                                                fill="white"
                                                            />
                                                        </g>
                                                        <defs>
                                                            <clipPath id="clip0_44_6">
                                                                <rect width="22" height="22" fill="white" />
                                                            </clipPath>
                                                        </defs>
                                                    </svg>
                                                    Elegant Vein Patterns
                                                </li>
                                            </ul>
                                            <a class="arrow-link" href="service-details.php">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="16" viewBox="0 0 26 16" fill="none">
                                                    <path
                                                        d="M25.7071 8.70711C26.0976 8.31658 26.0976 7.68342 25.7071 7.29289L19.3431 0.928932C18.9526 0.538408 18.3195 0.538408 17.9289 0.928932C17.5384 1.31946 17.5384 1.95262 17.9289 2.34315L23.5858 8L17.9289 13.6569C17.5384 14.0474 17.5384 14.6805 17.9289 15.0711C18.3195 15.4616 18.9526 15.4616 19.3431 15.0711L25.7071 8.70711ZM0 9H25V7H0V9Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="offer-card style1 img-custom-anim-right wow fadeInDown" data-wow-delay=".5s">
                                        <div class="bg"><img src="assets/images/offer/offerCardBg1_1.jpg" alt="bg" /></div>
                                        <div class="content">
                                            <div class="icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="none">
                                                    <g clip-path="url(#clip0_46_153)">
                                                        <path
                                                            opacity="0.96"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M14.8047 -0.0390625C22.9037 -0.0390625 31.0026 -0.0390625 39.1016 -0.0390625C39.4662 0.169271 39.7526 0.455729 39.9609 0.820312C39.9609 5.50781 39.9609 10.1953 39.9609 14.8828C39.5832 15.2958 39.2055 15.2958 38.8281 14.8828C38.8021 10.3776 38.776 5.8724 38.75 1.36719C38.7109 1.27604 38.6459 1.21094 38.5547 1.17188C30.7943 1.11979 23.0338 1.11979 15.2734 1.17188C15.1184 3.06808 15.0663 4.98214 15.1172 6.91406C17.4351 6.90105 19.7527 6.91406 22.0703 6.95312C22.3916 7.2273 22.4567 7.55282 22.2656 7.92969C22.1741 8.03852 22.057 8.10367 21.9141 8.125C17.3308 8.16406 12.7475 8.17711 8.16406 8.16406C8.16406 10.0651 8.16406 11.9662 8.16406 13.8672C13.7891 13.8541 19.4141 13.8672 25.0391 13.9062C25.5209 14.0755 25.8463 14.401 26.0156 14.8828C26.0547 20.5077 26.0677 26.1327 26.0547 31.7578C27.9557 31.7578 29.8568 31.7578 31.7578 31.7578C31.7448 31.0282 31.7578 30.299 31.7969 29.5703C32.1547 28.9791 32.5453 28.953 32.9688 29.4922C33.0209 30.3516 33.0209 31.2109 32.9688 32.0703C32.8255 32.526 32.526 32.8255 32.0703 32.9688C30.0652 33.0078 28.0601 33.0209 26.0547 33.0078C26.0677 34.9872 26.0547 36.9663 26.0156 38.9453C25.8893 39.4486 25.5898 39.7871 25.1172 39.9609C17.0182 39.9609 8.9193 39.9609 0.820312 39.9609C0.455729 39.7526 0.169271 39.4662 -0.0390625 39.1016C-0.0390625 31.0026 -0.0390625 22.9037 -0.0390625 14.8047C0.134727 14.332 0.473269 14.0326 0.976562 13.9062C2.95555 13.8672 4.93473 13.8541 6.91406 13.8672C6.90105 11.8618 6.91406 9.85664 6.95312 7.85156C7.09635 7.39584 7.39584 7.09635 7.85156 6.95312C9.85664 6.91406 11.8618 6.90105 13.8672 6.91406C13.8541 4.93473 13.8672 2.95555 13.9062 0.976562C14.0326 0.473269 14.332 0.134727 14.8047 -0.0390625ZM2.14844 15.1953C3.09841 15.1047 4.06196 15.0916 5.03906 15.1562C5.35156 15.4688 5.66406 15.7812 5.97656 16.0938C6.56352 16.4557 6.95415 16.3124 7.14844 15.6641C7.10195 15.4799 7.02382 15.3107 6.91406 15.1562C7.87758 15.1041 8.84117 15.1041 9.80469 15.1562C10.1432 15.4948 10.4818 15.8334 10.8203 16.1719C11.5308 16.4246 11.8563 16.1772 11.7969 15.4297C11.7605 15.3179 11.6954 15.2268 11.6016 15.1562C12.5651 15.1041 13.5287 15.1041 14.4922 15.1562C14.8047 15.4688 15.1172 15.7812 15.4297 16.0938C16.0166 16.4557 16.4073 16.3124 16.6016 15.6641C16.5551 15.4799 16.477 15.3107 16.3672 15.1562C17.3307 15.1041 18.2943 15.1041 19.2578 15.1562C19.5963 15.4948 19.9349 15.8334 20.2734 16.1719C20.9839 16.4246 21.3095 16.1772 21.25 15.4297C21.2137 15.3179 21.1485 15.2268 21.0547 15.1562C22.2975 15.0919 23.5345 15.1049 24.7656 15.1953C24.8177 16.4193 24.8177 17.6432 24.7656 18.8672C24.2049 18.4705 23.8013 18.5877 23.5547 19.2188C23.6011 19.4367 23.6923 19.632 23.8281 19.8047C24.1406 20.1172 24.4531 20.4297 24.7656 20.7422C24.8177 21.7057 24.8177 22.6693 24.7656 23.6328C24.1927 23.1479 23.7891 23.2651 23.5547 23.9844C23.5938 24.1016 23.6328 24.2188 23.6719 24.3359C24.0365 24.7005 24.401 25.0651 24.7656 25.4297C24.8177 26.3932 24.8177 27.3568 24.7656 28.3203C24.401 28.0078 24.0365 28.0078 23.6719 28.3203C23.5156 28.5547 23.5156 28.7891 23.6719 29.0234C24.0365 29.388 24.401 29.7526 24.7656 30.1172C24.8177 31.1068 24.8177 32.0963 24.7656 33.0859C24.1927 32.601 23.7891 32.7182 23.5547 33.4375C23.5938 33.5547 23.6328 33.6719 23.6719 33.7891C24.0365 34.1537 24.401 34.5182 24.7656 34.8828C24.8177 35.8463 24.8177 36.8099 24.7656 37.7734C24.401 37.4609 24.0365 37.4609 23.6719 37.7734C23.5071 38.1652 23.5982 38.4906 23.9453 38.75C22.9557 38.8021 21.9662 38.8021 20.9766 38.75C20.612 38.3854 20.2474 38.0209 19.8828 37.6562C19.1723 37.4035 18.8468 37.6509 18.9062 38.3984C18.9676 38.538 19.0587 38.6552 19.1797 38.75C18.2162 38.8021 17.2526 38.8021 16.2891 38.75C15.9245 38.3854 15.5599 38.0209 15.1953 37.6562C14.3823 37.3773 14.0568 37.6507 14.2188 38.4766C14.3099 38.5677 14.401 38.6588 14.4922 38.75C13.5026 38.8021 12.513 38.8021 11.5234 38.75C11.1588 38.3854 10.7943 38.0209 10.4297 37.6562C9.71922 37.4035 9.39367 37.6509 9.45312 38.3984C9.51445 38.538 9.60555 38.6552 9.72656 38.75C8.76305 38.8021 7.79948 38.8021 6.83594 38.75C6.47135 38.3854 6.10677 38.0209 5.74219 37.6562C5.16563 37.3848 4.80105 37.554 4.64844 38.1641C4.69965 38.4109 4.82985 38.6062 5.03906 38.75C3.8151 38.8021 2.59115 38.8021 1.36719 38.75C1.30405 38.7259 1.25198 38.6869 1.21094 38.6328C1.121 37.3862 1.10798 36.1362 1.17188 34.8828C1.49059 35.3042 1.85518 35.3563 2.26562 35.0391C2.42188 34.7526 2.42188 34.4662 2.26562 34.1797C1.90104 33.8151 1.53646 33.4505 1.17188 33.0859C1.11979 32.1224 1.11979 31.1588 1.17188 30.1953C1.5625 30.612 1.95312 30.612 2.34375 30.1953C2.40548 29.9505 2.37944 29.7161 2.26562 29.4922C1.90104 29.1276 1.53646 28.763 1.17188 28.3984C1.11979 27.4088 1.11979 26.4193 1.17188 25.4297C1.49059 25.8511 1.85518 25.9031 2.26562 25.5859C2.42188 25.2995 2.42188 25.013 2.26562 24.7266C1.90104 24.362 1.53646 23.9974 1.17188 23.6328C1.11979 22.6693 1.11979 21.7057 1.17188 20.7422C1.56841 21.1528 1.95903 21.1528 2.34375 20.7422C2.40548 20.4973 2.37944 20.263 2.26562 20.0391C1.90104 19.6745 1.53646 19.3099 1.17188 18.9453C1.11979 17.9557 1.11979 16.9662 1.17188 15.9766C1.56841 16.3872 1.95903 16.3872 2.34375 15.9766C2.43255 15.667 2.36745 15.4066 2.14844 15.1953Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.945"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M39.9609 16.8359C39.9609 19.5963 39.9609 22.3568 39.9609 25.1172C39.7871 25.5898 39.4486 25.8893 38.9453 26.0156C36.9663 26.0547 34.9872 26.0677 33.0078 26.0547C33.0208 26.5241 33.0077 26.9929 32.9687 27.4609C32.7016 27.7932 32.376 27.8584 31.9922 27.6563C31.8984 27.5857 31.8332 27.4946 31.7969 27.3828C31.7709 21.0026 31.7448 14.6224 31.7187 8.24219C29.2113 8.17742 26.6983 8.13836 24.1797 8.125C23.7423 7.91446 23.6252 7.58893 23.8281 7.14844C23.8987 7.05458 23.9898 6.98947 24.1016 6.95313C26.7318 6.90104 29.3619 6.90104 31.9922 6.95313C32.474 7.1224 32.7994 7.44792 32.9687 7.92969C33.0078 13.5546 33.0209 19.1796 33.0078 24.8047C34.9095 24.8307 36.8106 24.8047 38.7109 24.7266C38.7755 22.0996 38.8145 19.4694 38.8281 16.8359C39.2054 16.4244 39.583 16.4244 39.9609 16.8359Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.899"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M3.86719 16.2891C4.59206 16.2012 4.8655 16.5137 4.6875 17.2266C4.23177 17.6823 3.77604 18.138 3.32031 18.5937C2.5 18.8151 2.20052 18.5156 2.42187 17.6953C2.89546 17.2086 3.37723 16.7398 3.86719 16.2891Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.903"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M8.55468 16.2891C9.40601 16.2472 9.65335 16.6118 9.29687 17.3828C8.86163 17.8705 8.37984 18.3002 7.85155 18.6719C7.21032 18.7072 6.96292 18.4077 7.10937 17.7734C7.60698 17.2889 8.08874 16.7941 8.55468 16.2891Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.898"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M13.3203 16.2891C14.0452 16.2012 14.3186 16.5137 14.1406 17.2266C13.6849 17.6823 13.2291 18.138 12.7734 18.5937C11.9531 18.8151 11.6537 18.5156 11.875 17.6953C12.3486 17.2086 12.8304 16.7398 13.3203 16.2891Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.879"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M18.0078 16.2891C18.8591 16.2472 19.1065 16.6118 18.75 17.3828C18.3148 17.8705 17.833 18.3002 17.3047 18.6719C16.6634 18.7072 16.416 18.4077 16.5625 17.7734C17.0076 17.2372 17.4894 16.7424 18.0078 16.2891Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.899"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M22.6953 16.2891C23.5274 16.1835 23.8009 16.522 23.5156 17.3047C23.0859 17.7344 22.6563 18.1641 22.2266 18.5938C21.4063 18.8151 21.1068 18.5156 21.3281 17.6953C21.7997 17.2368 22.2555 16.768 22.6953 16.2891Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.895"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M5.03906 18.6328C5.28509 18.6102 5.51946 18.6493 5.74218 18.75C6.14583 19.1537 6.54947 19.5573 6.95312 19.9609C7.31026 20.7387 7.06286 21.0903 6.21093 21.0156C5.72916 20.5338 5.24739 20.0521 4.76562 19.5703C4.62714 19.1914 4.71829 18.8789 5.03906 18.6328Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.898"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M9.72657 18.6328C9.97258 18.6102 10.207 18.6493 10.4297 18.75C10.8594 19.1797 11.2891 19.6094 11.7188 20.0391C11.9209 20.4229 11.8557 20.7484 11.5234 21.0156C11.2786 21.0773 11.0442 21.0513 10.8203 20.9375C10.3906 20.5078 9.96094 20.0781 9.53126 19.6484C9.34422 19.2599 9.40938 18.9214 9.72657 18.6328Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.896"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M14.4922 18.6328C14.7827 18.5939 15.0432 18.6591 15.2734 18.8281C15.651 19.2057 16.0287 19.5834 16.4062 19.9609C16.7634 20.7388 16.516 21.0903 15.6641 21.0156C15.1823 20.5338 14.7005 20.0521 14.2187 19.5703C14.0802 19.1914 14.1714 18.8789 14.4922 18.6328Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.9"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M19.1797 18.6328C19.4257 18.6102 19.6601 18.6493 19.8828 18.75C20.3125 19.1797 20.7422 19.6094 21.1719 20.0391C21.4506 20.6093 21.2813 20.9478 20.6641 21.0547C20.5235 21.0487 20.3933 21.0096 20.2734 20.9375C19.8438 20.5078 19.4141 20.0781 18.9844 19.6484C18.7973 19.2599 18.8625 18.9214 19.1797 18.6328Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.903"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M3.94531 20.9766C4.69594 21.0121 4.91729 21.3767 4.60937 22.0703C4.17724 22.5286 3.7215 22.9583 3.24218 23.3594C2.4993 23.4762 2.22586 23.1766 2.42187 22.4609C2.92149 21.9482 3.42931 21.4534 3.94531 20.9766Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.896"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M8.63281 20.9766C9.37757 20.9563 9.62492 21.2948 9.37499 21.9922C8.94531 22.4219 8.51562 22.8516 8.08593 23.2813C7.21353 23.5547 6.91406 23.2552 7.18749 22.3828C7.66108 21.8961 8.14288 21.4273 8.63281 20.9766Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.879"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M13.3984 20.9766C14.0387 20.9788 14.2862 21.2913 14.1406 21.9141C13.7109 22.4479 13.2291 22.9297 12.6953 23.3594C11.843 23.4392 11.5956 23.0877 11.9531 22.3047C12.4034 21.8149 12.8851 21.3722 13.3984 20.9766Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.897"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M18.0859 20.9766C18.8307 20.9563 19.078 21.2948 18.8281 21.9922C18.3984 22.4219 17.9687 22.8516 17.5391 23.2813C16.6666 23.5547 16.3672 23.2552 16.6406 22.3828C17.1142 21.8961 17.596 21.4273 18.0859 20.9766Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.879"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M22.8516 20.9766C23.4919 20.9788 23.7393 21.2913 23.5937 21.9141C23.1641 22.4479 22.6823 22.9297 22.1484 23.3594C21.2961 23.4392 21.0487 23.0877 21.4062 22.3047C21.8565 21.8149 22.3382 21.3722 22.8516 20.9766Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.897"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M5.19531 23.3203C5.35658 23.3349 5.51283 23.374 5.66406 23.4375C6.11979 23.8932 6.57552 24.349 7.03125 24.8047C7.239 25.3267 7.06973 25.6652 6.52344 25.8203C6.39726 25.7692 6.26704 25.7302 6.13281 25.7031C5.67708 25.2474 5.22135 24.7916 4.76562 24.3359C4.58292 23.8546 4.72615 23.5161 5.19531 23.3203Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.895"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M9.88281 23.3203C10.1113 23.3172 10.3196 23.3823 10.5078 23.5156C10.9115 23.9193 11.3151 24.3229 11.7188 24.7266C11.9977 25.5396 11.7243 25.8651 10.8984 25.7031C10.4166 25.2213 9.93492 24.7396 9.45313 24.2578C9.32758 23.8063 9.47086 23.4938 9.88281 23.3203Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.895"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M14.5703 23.3203C14.7599 23.3221 14.9422 23.3612 15.1172 23.4375C15.5729 23.8932 16.0287 24.349 16.4844 24.8047C16.6804 25.3227 16.5111 25.6613 15.9766 25.8203C15.8504 25.7692 15.7202 25.7302 15.5859 25.7031C15.1302 25.2474 14.6745 24.7916 14.2188 24.3359C14.0484 23.8966 14.1656 23.5581 14.5703 23.3203Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.896"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M19.3359 23.3203C19.5645 23.3172 19.7727 23.3823 19.9609 23.5156C20.3385 23.8932 20.7162 24.2709 21.0938 24.6484C21.4558 25.2312 21.3126 25.6218 20.6641 25.8203C20.5629 25.7736 20.4588 25.7345 20.3516 25.7031C19.8698 25.2213 19.388 24.7396 18.9063 24.2578C18.7807 23.8063 18.924 23.4938 19.3359 23.3203Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.9"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M3.78907 25.7422C4.55704 25.6116 4.85652 25.9241 4.68751 26.6797C4.23178 27.1354 3.77604 27.5912 3.32032 28.0469C2.64274 28.2616 2.31722 28.0141 2.34376 27.3047C2.81287 26.7705 3.29464 26.2497 3.78907 25.7422Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.879"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M8.55468 25.7422C9.40601 25.7003 9.65335 26.0649 9.29687 26.8359C8.86163 27.3236 8.37984 27.7533 7.85155 28.125C7.21032 28.1603 6.96292 27.8609 7.10937 27.2266C7.55455 26.6903 8.03632 26.1955 8.55468 25.7422Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.897"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M13.2422 25.7422C14.0102 25.6116 14.3096 25.9241 14.1406 26.6797C13.6849 27.1354 13.2291 27.5912 12.7734 28.0469C11.9531 28.2682 11.6537 27.9687 11.875 27.1484C12.3466 26.6899 12.8023 26.2212 13.2422 25.7422Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.879"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M18.0078 25.7422C18.8591 25.7003 19.1065 26.0649 18.75 26.8359C18.3148 27.3236 17.833 27.7533 17.3047 28.125C16.6634 28.1603 16.416 27.8609 16.5625 27.2266C17.0076 26.6903 17.4894 26.1955 18.0078 25.7422Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.898"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M22.6953 25.7422C23.5274 25.6366 23.8009 25.9752 23.5156 26.7578C23.0859 27.1875 22.6563 27.6172 22.2266 28.0469C21.4063 28.2682 21.1068 27.9688 21.3281 27.1484C21.7997 26.6899 22.2555 26.2212 22.6953 25.7422Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.895"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M5.03906 28.0859C5.28509 28.0634 5.51946 28.1024 5.74218 28.2031C6.14583 28.6068 6.54947 29.0104 6.95312 29.4141C7.31026 30.1919 7.06286 30.5434 6.21093 30.4687C5.72916 29.987 5.24739 29.5052 4.76562 29.0234C4.62714 28.6445 4.71829 28.332 5.03906 28.0859Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.9"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M9.72657 28.0859C9.97258 28.0634 10.207 28.1024 10.4297 28.2031C10.8594 28.6328 11.2891 29.0625 11.7188 29.4922C11.9975 30.0624 11.8282 30.4009 11.2109 30.5078C11.0704 30.5018 10.9402 30.4627 10.8203 30.3906C10.3906 29.9609 9.96094 29.5312 9.53126 29.1016C9.34422 28.713 9.40938 28.3745 9.72657 28.0859Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.897"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M14.4922 28.0859C14.7382 28.0634 14.9726 28.1024 15.1953 28.2031C15.599 28.6068 16.0026 29.0104 16.4062 29.4141C16.6707 29.7498 16.6577 30.0754 16.3672 30.3906C16.1433 30.5045 15.9089 30.5305 15.6641 30.4688C15.1823 29.987 14.7005 29.5052 14.2187 29.0234C14.0802 28.6445 14.1714 28.332 14.4922 28.0859Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.898"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M19.1797 28.0859C19.4257 28.0634 19.6601 28.1024 19.8828 28.2031C20.3125 28.6328 20.7422 29.0625 21.1719 29.4922C21.4506 30.0624 21.2813 30.4009 20.6641 30.5078C20.5235 30.5018 20.3933 30.4627 20.2734 30.3906C19.8438 29.9609 19.4141 29.5312 18.9844 29.1016C18.7858 28.7061 18.8509 28.3676 19.1797 28.0859Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.879"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M3.94532 30.4297C4.58567 30.432 4.83306 30.7445 4.6875 31.3672C4.25782 31.901 3.77604 32.3828 3.24219 32.8125C2.38987 32.8923 2.14248 32.5408 2.5 31.7578C2.95022 31.268 3.43199 30.8253 3.94532 30.4297Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.897"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M8.63281 30.4297C9.37757 30.4095 9.62492 30.748 9.37499 31.4453C8.94531 31.875 8.51562 32.3047 8.08593 32.7344C7.21353 33.0078 6.91406 32.7084 7.18749 31.8359C7.66108 31.3492 8.14288 30.8805 8.63281 30.4297Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.879"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M13.3984 30.4297C14.0387 30.432 14.2862 30.7445 14.1406 31.3672C13.7109 31.901 13.2291 32.3828 12.6953 32.8125C11.843 32.8923 11.5956 32.5408 11.9531 31.7578C12.4034 31.268 12.8851 30.8253 13.3984 30.4297Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.895"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M18.0859 30.4297C18.8307 30.4095 19.0781 30.748 18.8281 31.4453C18.3984 31.875 17.9688 32.3047 17.5391 32.7344C16.7438 33.0203 16.4183 32.7469 16.5625 31.9141C17.0621 31.4013 17.5699 30.9065 18.0859 30.4297Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.903"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M22.8516 30.4297C23.4919 30.432 23.7393 30.7445 23.5937 31.3672C23.1119 31.849 22.6302 32.3307 22.1484 32.8125C21.2961 32.8923 21.0487 32.5408 21.4062 31.7578C21.8565 31.268 22.3382 30.8253 22.8516 30.4297Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.898"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M5.11719 32.7734C5.30678 32.7752 5.48907 32.8143 5.66407 32.8906C6.11979 33.3463 6.57553 33.8021 7.03125 34.2578C7.2398 34.8041 7.05751 35.1427 6.48438 35.2734C6.3425 35.2087 6.19927 35.1435 6.05469 35.0781C5.625 34.6484 5.19532 34.2188 4.76563 33.7891C4.5949 33.3508 4.71208 33.0122 5.11719 32.7734Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.895"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M9.88281 32.7734C10.1113 32.7703 10.3196 32.8354 10.5078 32.9688C10.9115 33.3724 11.3151 33.776 11.7188 34.1797C11.9977 34.9927 11.7243 35.3182 10.8984 35.1563C10.4166 34.6745 9.93492 34.1927 9.45313 33.7109C9.32758 33.2595 9.47086 32.947 9.88281 32.7734Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.897"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M14.5703 32.7734C14.7599 32.7752 14.9422 32.8143 15.1172 32.8906C15.5729 33.3463 16.0287 33.8021 16.4844 34.2578C16.6849 34.8017 16.5027 35.1403 15.9375 35.2734C15.8282 35.2166 15.711 35.1776 15.5859 35.1562C15.1302 34.7005 14.6745 34.2448 14.2188 33.7891C14.0484 33.3498 14.1656 33.0112 14.5703 32.7734Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.895"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M19.3359 32.7734C19.5645 32.7703 19.7727 32.8354 19.9609 32.9688C20.3646 33.3724 20.7682 33.776 21.1719 34.1797C21.4509 34.9927 21.1774 35.3182 20.3516 35.1563C19.8698 34.6745 19.388 34.1927 18.9063 33.7109C18.7807 33.2595 18.924 32.947 19.3359 32.7734Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.9"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M3.78907 35.1953C4.55704 35.0648 4.85652 35.3773 4.68751 36.1328C4.23178 36.5885 3.77604 37.0443 3.32032 37.5C2.64274 37.7147 2.31722 37.4673 2.34376 36.7578C2.81287 36.2237 3.29464 35.7028 3.78907 35.1953Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.878"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M8.55468 35.1953C9.40601 35.1534 9.65335 35.518 9.29687 36.2891C8.86163 36.7767 8.37984 37.2064 7.85155 37.5781C7.21032 37.6134 6.96292 37.314 7.10937 36.6797C7.55455 36.1434 8.03632 35.6487 8.55468 35.1953Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.901"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M13.2422 35.1953C13.9681 35.0548 14.2675 35.3412 14.1406 36.0547C13.7134 36.5601 13.2577 37.0419 12.7734 37.5C12.0959 37.7147 11.7703 37.4673 11.7969 36.7578C12.266 36.2237 12.7477 35.7028 13.2422 35.1953Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.901"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M18.0078 35.1953C18.6417 35.0876 18.9412 35.348 18.9063 35.9766C18.4531 36.508 17.9713 37.0158 17.4609 37.5C16.7452 37.696 16.4457 37.4226 16.5625 36.6797C17.0077 36.1434 17.4895 35.6487 18.0078 35.1953Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.9"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M22.6953 35.1953C23.5274 35.0898 23.8009 35.4283 23.5156 36.2109C23.0859 36.6406 22.6563 37.0703 22.2266 37.5C21.4049 37.7201 21.1055 37.4205 21.3281 36.6016C21.7997 36.143 22.2555 35.6743 22.6953 35.1953Z"
                                                            fill="white"
                                                        />
                                                    </g>
                                                    <defs>
                                                        <clipPath id="clip0_46_153">
                                                            <rect width="40" height="40" fill="white" />
                                                        </clipPath>
                                                    </defs>
                                                </svg>
                                            </div>
                                            <h3>
                                                <a href="service-details.php">Modern Tiless</a>
                                            </h3>
                                            <p class="text">There are many flo variations of passages of atitl Lorem Ipsum available, but thedw,</p>
                                            <ul class="checklist style1">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22" fill="none">
                                                        <g clip-path="url(#clip0_44_7)">
                                                            <path
                                                                opacity="0.964"
                                                                fill-rule="evenodd"
                                                                clip-rule="evenodd"
                                                                d="M10.7422 0.242159C11.2869 0.214254 11.7869 0.347065 12.2422 0.640597C12.8625 1.12005 13.4406 1.6513 13.9766 2.23435C14.2725 2.49163 14.6163 2.64788 15.0078 2.7031C15.7898 2.74525 16.5711 2.79212 17.3516 2.84372C18.2812 3.08591 18.8672 3.67185 19.1094 4.60153C19.1672 5.31844 19.1984 6.03717 19.2031 6.75778C19.1858 7.22025 19.3265 7.62652 19.625 7.97653C20.2393 8.54367 20.8018 9.15305 21.3125 9.80466C21.8012 10.5826 21.8324 11.3795 21.4063 12.1953C20.8975 12.8919 20.3194 13.5325 19.6719 14.1172C19.3311 14.4867 19.1749 14.9242 19.2031 15.4297C19.1875 16.0703 19.1719 16.7109 19.1563 17.3515C18.9785 18.4668 18.33 19.1153 17.2109 19.2968C16.4171 19.3876 15.6202 19.4345 14.8203 19.4375C14.6558 19.4573 14.4996 19.5041 14.3516 19.5781C13.978 19.9048 13.6186 20.2485 13.2734 20.6093C12.8053 21.0619 12.274 21.4212 11.6797 21.6875C10.9165 21.9067 10.2134 21.7817 9.57032 21.3125C8.97655 20.7812 8.41405 20.2187 7.88282 19.625C7.58118 19.3415 7.22183 19.2009 6.80469 19.2031C3.74966 19.6167 2.39809 18.2964 2.75001 15.2422C2.77494 14.7632 2.63431 14.3414 2.32813 13.9765C1.78125 13.4922 1.26563 12.9765 0.781256 12.4297C0.125105 11.5554 0.0782299 10.6492 0.640631 9.71091C1.12008 9.09061 1.65134 8.51246 2.23438 7.97653C2.56328 7.56816 2.73516 7.09941 2.75001 6.57028C2.75405 5.88066 2.7853 5.19314 2.84376 4.50778C3.06515 3.58325 3.63546 2.99732 4.55469 2.74997C5.33277 2.65826 6.11404 2.61139 6.89844 2.60935C7.21921 2.5662 7.51612 2.45682 7.78907 2.28122C8.38457 1.73249 8.99394 1.20124 9.61719 0.687472C9.97012 0.468579 10.3451 0.32014 10.7422 0.242159ZM10.8359 1.69528C11.0475 1.69941 11.235 1.76972 11.3984 1.90622C11.9609 2.43747 12.5234 2.96872 13.0859 3.49997C13.5672 3.88894 14.1141 4.13897 14.7266 4.24997C15.3818 4.29994 16.0381 4.33121 16.6953 4.34372C17.0189 4.36214 17.2767 4.49494 17.4688 4.74216C17.5348 4.90889 17.5816 5.08078 17.6094 5.25778C17.6211 5.94628 17.6524 6.6338 17.7031 7.32028C17.7838 7.78121 17.9556 8.20308 18.2188 8.58591C18.7955 9.20953 19.3892 9.81891 20 10.414C20.1238 10.5835 20.2097 10.771 20.2578 10.9765C20.1611 11.2169 20.0282 11.4357 19.8594 11.6328C19.3424 12.1342 18.8423 12.6498 18.3594 13.1797C18.0054 13.6004 17.7866 14.0848 17.7031 14.6328C17.6524 15.3193 17.6211 16.0068 17.6094 16.6953C17.591 17.0188 17.4582 17.2766 17.2109 17.4687C17.0442 17.5347 16.8723 17.5816 16.6953 17.6093C16.0389 17.6378 15.3827 17.669 14.7266 17.7031C13.6811 17.8386 12.8764 18.3464 12.3125 19.2265C12.0534 19.4856 11.7956 19.7434 11.5391 20C11.3696 20.1238 11.1821 20.2097 10.9766 20.2578C10.7711 20.2097 10.5836 20.1238 10.4141 20C9.97396 19.6067 9.58335 19.1693 9.24219 18.6875C8.69929 18.1738 8.05869 17.8457 7.32032 17.7031C6.63374 17.6537 5.94623 17.6225 5.25782 17.6093C4.93429 17.5909 4.67648 17.4581 4.48438 17.2109C4.41838 17.0442 4.37151 16.8723 4.34376 16.6953C4.33199 16.0068 4.30077 15.3193 4.25001 14.6328C4.16938 14.1719 3.99754 13.75 3.73438 13.3672C3.15764 12.7435 2.56389 12.1342 1.95313 11.539C1.83569 11.3745 1.74975 11.1948 1.69532 11C1.78554 10.7493 1.91835 10.5228 2.09376 10.3203C2.57955 9.85017 3.0483 9.36577 3.50001 8.86716C3.88898 8.38594 4.13901 7.83905 4.25001 7.22653C4.30138 6.57136 4.33265 5.91511 4.34376 5.25778C4.36719 4.67185 4.67188 4.36716 5.25782 4.34372C5.89954 4.33224 6.54018 4.30097 7.17969 4.24997C7.80013 4.12721 8.36263 3.87722 8.86719 3.49997C9.27229 3.11044 9.66294 2.70418 10.0391 2.28122C10.2746 2.03912 10.5402 1.84381 10.8359 1.69528Z"
                                                                fill="white"
                                                            />
                                                            <path
                                                                opacity="0.959"
                                                                fill-rule="evenodd"
                                                                clip-rule="evenodd"
                                                                d="M13.6953 7.69531C14.5874 7.6573 14.9077 8.06356 14.6562 8.91406C13.2354 10.6241 11.8057 12.3272 10.3672 14.0234C10.1639 14.1368 9.95298 14.2306 9.73436 14.3047C9.57573 14.2779 9.42728 14.2232 9.28905 14.1406C8.64062 13.5547 7.99216 12.9687 7.34373 12.3828C7.20944 12.0926 7.19378 11.7957 7.29686 11.4922C7.43561 11.2351 7.65437 11.1101 7.95311 11.1172C8.16203 11.1245 8.35736 11.1792 8.53905 11.2812C8.92187 11.6328 9.30466 11.9844 9.68748 12.3359C10.8594 10.9297 12.0312 9.52344 13.2031 8.11719C13.3486 7.94778 13.5126 7.80715 13.6953 7.69531Z"
                                                                fill="white"
                                                            />
                                                        </g>
                                                        <defs>
                                                            <clipPath id="clip0_44_7">
                                                                <rect width="22" height="22" fill="white" />
                                                            </clipPath>
                                                        </defs>
                                                    </svg>
                                                    More Expensive
                                                </li>
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22" fill="none">
                                                        <g clip-path="url(#clip0_44_8)">
                                                            <path
                                                                opacity="0.964"
                                                                fill-rule="evenodd"
                                                                clip-rule="evenodd"
                                                                d="M10.7422 0.242159C11.2869 0.214254 11.7869 0.347065 12.2422 0.640597C12.8625 1.12005 13.4406 1.6513 13.9766 2.23435C14.2725 2.49163 14.6163 2.64788 15.0078 2.7031C15.7898 2.74525 16.5711 2.79212 17.3516 2.84372C18.2812 3.08591 18.8672 3.67185 19.1094 4.60153C19.1672 5.31844 19.1984 6.03717 19.2031 6.75778C19.1858 7.22025 19.3265 7.62652 19.625 7.97653C20.2393 8.54367 20.8018 9.15305 21.3125 9.80466C21.8012 10.5826 21.8324 11.3795 21.4063 12.1953C20.8975 12.8919 20.3194 13.5325 19.6719 14.1172C19.3311 14.4867 19.1749 14.9242 19.2031 15.4297C19.1875 16.0703 19.1719 16.7109 19.1563 17.3515C18.9785 18.4668 18.33 19.1153 17.2109 19.2968C16.4171 19.3876 15.6202 19.4345 14.8203 19.4375C14.6558 19.4573 14.4996 19.5041 14.3516 19.5781C13.978 19.9048 13.6186 20.2485 13.2734 20.6093C12.8053 21.0619 12.274 21.4212 11.6797 21.6875C10.9165 21.9067 10.2134 21.7817 9.57032 21.3125C8.97655 20.7812 8.41405 20.2187 7.88282 19.625C7.58118 19.3415 7.22183 19.2009 6.80469 19.2031C3.74966 19.6167 2.39809 18.2964 2.75001 15.2422C2.77494 14.7632 2.63431 14.3414 2.32813 13.9765C1.78125 13.4922 1.26563 12.9765 0.781256 12.4297C0.125105 11.5554 0.0782299 10.6492 0.640631 9.71091C1.12008 9.09061 1.65134 8.51246 2.23438 7.97653C2.56328 7.56816 2.73516 7.09941 2.75001 6.57028C2.75405 5.88066 2.7853 5.19314 2.84376 4.50778C3.06515 3.58325 3.63546 2.99732 4.55469 2.74997C5.33277 2.65826 6.11404 2.61139 6.89844 2.60935C7.21921 2.5662 7.51612 2.45682 7.78907 2.28122C8.38457 1.73249 8.99394 1.20124 9.61719 0.687472C9.97012 0.468579 10.3451 0.32014 10.7422 0.242159ZM10.8359 1.69528C11.0475 1.69941 11.235 1.76972 11.3984 1.90622C11.9609 2.43747 12.5234 2.96872 13.0859 3.49997C13.5672 3.88894 14.1141 4.13897 14.7266 4.24997C15.3818 4.29994 16.0381 4.33121 16.6953 4.34372C17.0189 4.36214 17.2767 4.49494 17.4688 4.74216C17.5348 4.90889 17.5816 5.08078 17.6094 5.25778C17.6211 5.94628 17.6524 6.6338 17.7031 7.32028C17.7838 7.78121 17.9556 8.20308 18.2188 8.58591C18.7955 9.20953 19.3892 9.81891 20 10.414C20.1238 10.5835 20.2097 10.771 20.2578 10.9765C20.1611 11.2169 20.0282 11.4357 19.8594 11.6328C19.3424 12.1342 18.8423 12.6498 18.3594 13.1797C18.0054 13.6004 17.7866 14.0848 17.7031 14.6328C17.6524 15.3193 17.6211 16.0068 17.6094 16.6953C17.591 17.0188 17.4582 17.2766 17.2109 17.4687C17.0442 17.5347 16.8723 17.5816 16.6953 17.6093C16.0389 17.6378 15.3827 17.669 14.7266 17.7031C13.6811 17.8386 12.8764 18.3464 12.3125 19.2265C12.0534 19.4856 11.7956 19.7434 11.5391 20C11.3696 20.1238 11.1821 20.2097 10.9766 20.2578C10.7711 20.2097 10.5836 20.1238 10.4141 20C9.97396 19.6067 9.58335 19.1693 9.24219 18.6875C8.69929 18.1738 8.05869 17.8457 7.32032 17.7031C6.63374 17.6537 5.94623 17.6225 5.25782 17.6093C4.93429 17.5909 4.67648 17.4581 4.48438 17.2109C4.41838 17.0442 4.37151 16.8723 4.34376 16.6953C4.33199 16.0068 4.30077 15.3193 4.25001 14.6328C4.16938 14.1719 3.99754 13.75 3.73438 13.3672C3.15764 12.7435 2.56389 12.1342 1.95313 11.539C1.83569 11.3745 1.74975 11.1948 1.69532 11C1.78554 10.7493 1.91835 10.5228 2.09376 10.3203C2.57955 9.85017 3.0483 9.36577 3.50001 8.86716C3.88898 8.38594 4.13901 7.83905 4.25001 7.22653C4.30138 6.57136 4.33265 5.91511 4.34376 5.25778C4.36719 4.67185 4.67188 4.36716 5.25782 4.34372C5.89954 4.33224 6.54018 4.30097 7.17969 4.24997C7.80013 4.12721 8.36263 3.87722 8.86719 3.49997C9.27229 3.11044 9.66294 2.70418 10.0391 2.28122C10.2746 2.03912 10.5402 1.84381 10.8359 1.69528Z"
                                                                fill="white"
                                                            />
                                                            <path
                                                                opacity="0.959"
                                                                fill-rule="evenodd"
                                                                clip-rule="evenodd"
                                                                d="M13.6953 7.69531C14.5874 7.6573 14.9077 8.06356 14.6562 8.91406C13.2354 10.6241 11.8057 12.3272 10.3672 14.0234C10.1639 14.1368 9.95298 14.2306 9.73436 14.3047C9.57573 14.2779 9.42728 14.2232 9.28905 14.1406C8.64062 13.5547 7.99216 12.9687 7.34373 12.3828C7.20944 12.0926 7.19378 11.7957 7.29686 11.4922C7.43561 11.2351 7.65437 11.1101 7.95311 11.1172C8.16203 11.1245 8.35736 11.1792 8.53905 11.2812C8.92187 11.6328 9.30466 11.9844 9.68748 12.3359C10.8594 10.9297 12.0312 9.52344 13.2031 8.11719C13.3486 7.94778 13.5126 7.80715 13.6953 7.69531Z"
                                                                fill="white"
                                                            />
                                                        </g>
                                                        <defs>
                                                            <clipPath id="clip0_44_8">
                                                                <rect width="22" height="22" fill="white" />
                                                            </clipPath>
                                                        </defs>
                                                    </svg>
                                                    Elegant Vein Patterns
                                                </li>
                                            </ul>
                                            <a class="arrow-link" href="service-details.php">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="16" viewBox="0 0 26 16" fill="none">
                                                    <path
                                                        d="M25.7071 8.70711C26.0976 8.31658 26.0976 7.68342 25.7071 7.29289L19.3431 0.928932C18.9526 0.538408 18.3195 0.538408 17.9289 0.928932C17.5384 1.31946 17.5384 1.95262 17.9289 2.34315L23.5858 8L17.9289 13.6569C17.5384 14.0474 17.5384 14.6805 17.9289 15.0711C18.3195 15.4616 18.9526 15.4616 19.3431 15.0711L25.7071 8.70711ZM0 9H25V7H0V9Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="offer-card style1 img-custom-anim-top wow fadeInUp" data-wow-delay=".7s">
                                        <div class="bg"><img src="assets/images/offer/offerCardBg1_1.jpg" alt="bg" /></div>
                                        <div class="content">
                                            <div class="icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="none">
                                                    <path
                                                        opacity="0.936"
                                                        fill-rule="evenodd"
                                                        clip-rule="evenodd"
                                                        d="M13.6328 1.36719C17.8516 1.35417 22.0704 1.36719 26.2891 1.40625C26.4101 1.50109 26.5012 1.61828 26.5625 1.75781C26.6016 3.45032 26.6146 5.14303 26.6016 6.83594C30.4819 6.82292 34.362 6.83594 38.2422 6.875C38.3854 6.91406 38.4766 7.00521 38.5156 7.14844C38.5677 17.513 38.5677 27.8776 38.5156 38.2422C38.4766 38.3854 38.3854 38.4766 38.2422 38.5156C34.0756 38.5677 29.9088 38.5677 25.7422 38.5156C25.599 38.4766 25.5078 38.3854 25.4688 38.2422C25.4297 36.5237 25.4166 34.8049 25.4297 33.0859C21.7838 33.0859 18.1381 33.0859 14.4922 33.0859C14.5052 33.8937 14.4922 34.7009 14.4531 35.5078C14.4141 35.651 14.3229 35.7422 14.1797 35.7812C10.013 35.8334 5.84635 35.8334 1.67969 35.7812C1.53646 35.7422 1.44531 35.651 1.40625 35.5078C1.35417 25.1432 1.35417 14.7787 1.40625 4.41406C1.44531 4.27084 1.53646 4.17969 1.67969 4.14063C5.55981 4.10156 9.44 4.08854 13.3203 4.10156C13.3073 3.31988 13.3203 2.53863 13.3594 1.75781C13.4373 1.61538 13.5284 1.48518 13.6328 1.36719ZM14.4922 2.53906C15.4297 2.53906 16.3672 2.53906 17.3047 2.53906C17.2916 4.67464 17.3047 6.81006 17.3438 8.94531C17.5401 9.23531 17.8135 9.32641 18.1641 9.21875C18.2851 9.12391 18.3762 9.00672 18.4375 8.86719C18.4766 6.75798 18.4896 4.6486 18.4766 2.53906C19.4662 2.53906 20.4557 2.53906 21.4453 2.53906C21.4323 6.49749 21.4453 10.4558 21.4844 14.4141C21.858 14.9158 22.2227 14.9158 22.5781 14.4141C22.6172 10.4558 22.6302 6.49749 22.6172 2.53906C23.5547 2.53906 24.4922 2.53906 25.4297 2.53906C25.4297 12.3307 25.4297 22.1224 25.4297 31.9141C23.112 31.9141 20.7943 31.9141 18.4766 31.9141C18.4896 28.0859 18.4766 24.2577 18.4375 20.4297C18.3602 20.1363 18.1649 20.0061 17.8516 20.0391C17.5926 19.9988 17.4233 20.1029 17.3438 20.3516C17.3047 24.2056 17.2916 28.0598 17.3047 31.9141C16.3672 31.9141 15.4297 31.9141 14.4922 31.9141C14.4922 22.1224 14.4922 12.3307 14.4922 2.53906ZM2.53906 5.27344C3.5026 5.27344 4.46615 5.27344 5.42969 5.27344C5.41667 6.47164 5.4297 7.66956 5.46875 8.86719C5.69635 9.27258 6.02187 9.36375 6.44531 9.14063C6.4942 9.08203 6.53327 9.01688 6.5625 8.94531C6.60156 7.72163 6.61458 6.49767 6.60156 5.27344C7.53906 5.27344 8.47656 5.27344 9.41406 5.27344C9.40102 10.6902 9.41406 16.1068 9.45313 21.5234C9.70321 21.8561 10.0027 21.9082 10.3516 21.6797C10.4536 21.5694 10.5188 21.4391 10.5469 21.2891C10.5859 15.9505 10.599 10.612 10.5859 5.27344C11.4974 5.27344 12.4088 5.27344 13.3203 5.27344C13.3203 15.0651 13.3203 24.8568 13.3203 34.6484C11.0807 34.6484 8.84117 34.6484 6.60156 34.6484C6.61458 32.9295 6.60156 31.2107 6.5625 29.4922C6.32614 29.164 6.02667 29.0988 5.66406 29.2969C5.55522 29.3884 5.49012 29.5055 5.46875 29.6484C5.42969 31.3149 5.41667 32.9816 5.42969 34.6484C4.46615 34.6484 3.5026 34.6484 2.53906 34.6484C2.53906 24.8568 2.53906 15.0651 2.53906 5.27344ZM26.6016 8.00781C28.8932 8.00781 31.1849 8.00781 33.4766 8.00781C33.4635 10.4038 33.4766 12.7996 33.5156 15.1953C33.8541 15.5078 34.1927 15.5078 34.5313 15.1953C34.5703 12.7996 34.5834 10.4038 34.5703 8.00781C35.5078 8.00781 36.4453 8.00781 37.3828 8.00781C37.3828 17.7995 37.3828 27.5912 37.3828 37.3828C35.1432 37.3828 32.9037 37.3828 30.6641 37.3828C30.6771 35.6638 30.6641 33.9451 30.625 32.2266C30.1769 31.7748 29.8123 31.8269 29.5313 32.3828C29.4922 34.0493 29.4791 35.7159 29.4922 37.3828C28.5287 37.3828 27.5651 37.3828 26.6016 37.3828C26.6016 27.5912 26.6016 17.7995 26.6016 8.00781Z"
                                                        fill="white"
                                                    />
                                                    <path
                                                        opacity="0.927"
                                                        fill-rule="evenodd"
                                                        clip-rule="evenodd"
                                                        d="M29.8047 10.6641C29.9888 10.6513 30.1711 10.6643 30.3516 10.7031C30.4948 10.7422 30.5859 10.8334 30.625 10.9766C30.6771 14.987 30.6771 18.9974 30.625 23.0078C30.1995 23.4222 29.835 23.3701 29.5313 22.8516C29.4791 18.9193 29.4791 14.987 29.5313 11.0547C29.6091 10.9123 29.7003 10.782 29.8047 10.6641Z"
                                                        fill="white"
                                                    />
                                                    <path
                                                        opacity="0.91"
                                                        fill-rule="evenodd"
                                                        clip-rule="evenodd"
                                                        d="M17.6953 11.8359C18.0381 11.7924 18.2856 11.9227 18.4375 12.2266C18.4896 13.2682 18.4896 14.3099 18.4375 15.3516C18.2099 15.757 17.8844 15.8481 17.4609 15.625C17.412 15.5664 17.373 15.5013 17.3438 15.4297C17.2916 14.3359 17.2916 13.2422 17.3438 12.1484C17.4529 12.0258 17.5701 11.9216 17.6953 11.8359Z"
                                                        fill="white"
                                                    />
                                                    <path
                                                        opacity="0.926"
                                                        fill-rule="evenodd"
                                                        clip-rule="evenodd"
                                                        d="M5.82031 12.6172C6.14366 12.555 6.39106 12.6591 6.5625 12.9297C6.61459 16.8359 6.61459 20.7422 6.5625 24.6484C6.31731 24.967 6.01782 25.032 5.66406 24.8437C5.55522 24.7523 5.49012 24.6351 5.46875 24.4922C5.41667 20.6641 5.41667 16.8359 5.46875 13.0078C5.54883 12.837 5.66602 12.7067 5.82031 12.6172Z"
                                                        fill="white"
                                                    />
                                                    <path
                                                        opacity="0.921"
                                                        fill-rule="evenodd"
                                                        clip-rule="evenodd"
                                                        d="M21.8359 16.7578C22.1427 16.7224 22.39 16.8266 22.5781 17.0703C22.6302 19.0234 22.6302 20.9766 22.5781 22.9297C22.3237 23.3363 21.9981 23.4015 21.6016 23.125C21.5476 23.0416 21.5085 22.9505 21.4844 22.8516C21.4323 20.9506 21.4323 19.0495 21.4844 17.1484C21.5645 16.9776 21.6816 16.8473 21.8359 16.7578Z"
                                                        fill="white"
                                                    />
                                                    <path
                                                        opacity="0.991"
                                                        fill-rule="evenodd"
                                                        clip-rule="evenodd"
                                                        d="M33.7891 18.6328C34.1159 18.5706 34.3633 18.6748 34.5313 18.9453C34.5834 24.2057 34.5834 29.4662 34.5313 34.7266C34.1927 35.0391 33.8541 35.0391 33.5156 34.7266C33.4635 29.4662 33.4635 24.2057 33.5156 18.9453C33.5695 18.8008 33.6606 18.6966 33.7891 18.6328Z"
                                                        fill="white"
                                                    />
                                                    <path
                                                        opacity="0.901"
                                                        fill-rule="evenodd"
                                                        clip-rule="evenodd"
                                                        d="M21.8359 25.8203C22.1427 25.7849 22.39 25.8891 22.5781 26.1328C22.6302 27.0182 22.6302 27.9037 22.5781 28.7891C22.2135 29.3099 21.849 29.3099 21.4844 28.7891C21.4323 27.9297 21.4323 27.0703 21.4844 26.2109C21.5645 26.0401 21.6816 25.9098 21.8359 25.8203Z"
                                                        fill="white"
                                                    />
                                                    <path
                                                        opacity="0.961"
                                                        fill-rule="evenodd"
                                                        clip-rule="evenodd"
                                                        d="M9.72656 26.2109C10.0534 26.1488 10.3008 26.2529 10.4687 26.5234C10.5209 27.6432 10.5209 28.763 10.4687 29.8828C10.1302 30.1953 9.79164 30.1953 9.45312 29.8828C9.40101 28.763 9.40101 27.6432 9.45312 26.5234C9.50703 26.3789 9.59812 26.2747 9.72656 26.2109Z"
                                                        fill="white"
                                                    />
                                                    <path
                                                        opacity="0.894"
                                                        fill-rule="evenodd"
                                                        clip-rule="evenodd"
                                                        d="M29.9609 27.3047C30.2363 27.2927 30.4577 27.3968 30.625 27.6172C30.6771 28.2943 30.6771 28.9713 30.625 29.6484C30.4287 29.9384 30.1552 30.0295 29.8047 29.9219C29.6837 29.827 29.5926 29.7098 29.5312 29.5703C29.4602 28.8872 29.4862 28.2101 29.6094 27.5391C29.7194 27.439 29.8366 27.3609 29.9609 27.3047Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <h3>
                                                <a href="service-details.php">Wood Floor Repair</a>
                                            </h3>
                                            <p class="text">There are many flo variations of passages of atitl Lorem Ipsum available, but thedw,</p>
                                            <ul class="checklist style1">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22" fill="none">
                                                        <g clip-path="url(#clip0_44_10)">
                                                            <path
                                                                opacity="0.964"
                                                                fill-rule="evenodd"
                                                                clip-rule="evenodd"
                                                                d="M10.7422 0.242159C11.2869 0.214254 11.7869 0.347065 12.2422 0.640597C12.8625 1.12005 13.4406 1.6513 13.9766 2.23435C14.2725 2.49163 14.6163 2.64788 15.0078 2.7031C15.7898 2.74525 16.5711 2.79212 17.3516 2.84372C18.2812 3.08591 18.8672 3.67185 19.1094 4.60153C19.1672 5.31844 19.1984 6.03717 19.2031 6.75778C19.1858 7.22025 19.3265 7.62652 19.625 7.97653C20.2393 8.54367 20.8018 9.15305 21.3125 9.80466C21.8012 10.5826 21.8324 11.3795 21.4063 12.1953C20.8975 12.8919 20.3194 13.5325 19.6719 14.1172C19.3311 14.4867 19.1749 14.9242 19.2031 15.4297C19.1875 16.0703 19.1719 16.7109 19.1563 17.3515C18.9785 18.4668 18.33 19.1153 17.2109 19.2968C16.4171 19.3876 15.6202 19.4345 14.8203 19.4375C14.6558 19.4573 14.4996 19.5041 14.3516 19.5781C13.978 19.9048 13.6186 20.2485 13.2734 20.6093C12.8053 21.0619 12.274 21.4212 11.6797 21.6875C10.9165 21.9067 10.2134 21.7817 9.57032 21.3125C8.97655 20.7812 8.41405 20.2187 7.88282 19.625C7.58118 19.3415 7.22183 19.2009 6.80469 19.2031C3.74966 19.6167 2.39809 18.2964 2.75001 15.2422C2.77494 14.7632 2.63431 14.3414 2.32813 13.9765C1.78125 13.4922 1.26563 12.9765 0.781256 12.4297C0.125105 11.5554 0.0782299 10.6492 0.640631 9.71091C1.12008 9.09061 1.65134 8.51246 2.23438 7.97653C2.56328 7.56816 2.73516 7.09941 2.75001 6.57028C2.75405 5.88066 2.7853 5.19314 2.84376 4.50778C3.06515 3.58325 3.63546 2.99732 4.55469 2.74997C5.33277 2.65826 6.11404 2.61139 6.89844 2.60935C7.21921 2.5662 7.51612 2.45682 7.78907 2.28122C8.38457 1.73249 8.99394 1.20124 9.61719 0.687472C9.97012 0.468579 10.3451 0.32014 10.7422 0.242159ZM10.8359 1.69528C11.0475 1.69941 11.235 1.76972 11.3984 1.90622C11.9609 2.43747 12.5234 2.96872 13.0859 3.49997C13.5672 3.88894 14.1141 4.13897 14.7266 4.24997C15.3818 4.29994 16.0381 4.33121 16.6953 4.34372C17.0189 4.36214 17.2767 4.49494 17.4688 4.74216C17.5348 4.90889 17.5816 5.08078 17.6094 5.25778C17.6211 5.94628 17.6524 6.6338 17.7031 7.32028C17.7838 7.78121 17.9556 8.20308 18.2188 8.58591C18.7955 9.20953 19.3892 9.81891 20 10.414C20.1238 10.5835 20.2097 10.771 20.2578 10.9765C20.1611 11.2169 20.0282 11.4357 19.8594 11.6328C19.3424 12.1342 18.8423 12.6498 18.3594 13.1797C18.0054 13.6004 17.7866 14.0848 17.7031 14.6328C17.6524 15.3193 17.6211 16.0068 17.6094 16.6953C17.591 17.0188 17.4582 17.2766 17.2109 17.4687C17.0442 17.5347 16.8723 17.5816 16.6953 17.6093C16.0389 17.6378 15.3827 17.669 14.7266 17.7031C13.6811 17.8386 12.8764 18.3464 12.3125 19.2265C12.0534 19.4856 11.7956 19.7434 11.5391 20C11.3696 20.1238 11.1821 20.2097 10.9766 20.2578C10.7711 20.2097 10.5836 20.1238 10.4141 20C9.97396 19.6067 9.58335 19.1693 9.24219 18.6875C8.69929 18.1738 8.05869 17.8457 7.32032 17.7031C6.63374 17.6537 5.94623 17.6225 5.25782 17.6093C4.93429 17.5909 4.67648 17.4581 4.48438 17.2109C4.41838 17.0442 4.37151 16.8723 4.34376 16.6953C4.33199 16.0068 4.30077 15.3193 4.25001 14.6328C4.16938 14.1719 3.99754 13.75 3.73438 13.3672C3.15764 12.7435 2.56389 12.1342 1.95313 11.539C1.83569 11.3745 1.74975 11.1948 1.69532 11C1.78554 10.7493 1.91835 10.5228 2.09376 10.3203C2.57955 9.85017 3.0483 9.36577 3.50001 8.86716C3.88898 8.38594 4.13901 7.83905 4.25001 7.22653C4.30138 6.57136 4.33265 5.91511 4.34376 5.25778C4.36719 4.67185 4.67188 4.36716 5.25782 4.34372C5.89954 4.33224 6.54018 4.30097 7.17969 4.24997C7.80013 4.12721 8.36263 3.87722 8.86719 3.49997C9.27229 3.11044 9.66294 2.70418 10.0391 2.28122C10.2746 2.03912 10.5402 1.84381 10.8359 1.69528Z"
                                                                fill="white"
                                                            />
                                                            <path
                                                                opacity="0.959"
                                                                fill-rule="evenodd"
                                                                clip-rule="evenodd"
                                                                d="M13.6953 7.69531C14.5874 7.6573 14.9077 8.06356 14.6562 8.91406C13.2354 10.6241 11.8057 12.3272 10.3672 14.0234C10.1639 14.1368 9.95298 14.2306 9.73436 14.3047C9.57573 14.2779 9.42728 14.2232 9.28905 14.1406C8.64062 13.5547 7.99216 12.9687 7.34373 12.3828C7.20944 12.0926 7.19378 11.7957 7.29686 11.4922C7.43561 11.2351 7.65437 11.1101 7.95311 11.1172C8.16203 11.1245 8.35736 11.1792 8.53905 11.2812C8.92187 11.6328 9.30466 11.9844 9.68748 12.3359C10.8594 10.9297 12.0312 9.52344 13.2031 8.11719C13.3486 7.94778 13.5126 7.80715 13.6953 7.69531Z"
                                                                fill="white"
                                                            />
                                                        </g>
                                                        <defs>
                                                            <clipPath id="clip0_44_10">
                                                                <rect width="22" height="22" fill="white" />
                                                            </clipPath>
                                                        </defs>
                                                    </svg>
                                                    More Expensive
                                                </li>
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22" fill="none">
                                                        <g clip-path="url(#clip0_44_11)">
                                                            <path
                                                                opacity="0.964"
                                                                fill-rule="evenodd"
                                                                clip-rule="evenodd"
                                                                d="M10.7422 0.242159C11.2869 0.214254 11.7869 0.347065 12.2422 0.640597C12.8625 1.12005 13.4406 1.6513 13.9766 2.23435C14.2725 2.49163 14.6163 2.64788 15.0078 2.7031C15.7898 2.74525 16.5711 2.79212 17.3516 2.84372C18.2812 3.08591 18.8672 3.67185 19.1094 4.60153C19.1672 5.31844 19.1984 6.03717 19.2031 6.75778C19.1858 7.22025 19.3265 7.62652 19.625 7.97653C20.2393 8.54367 20.8018 9.15305 21.3125 9.80466C21.8012 10.5826 21.8324 11.3795 21.4063 12.1953C20.8975 12.8919 20.3194 13.5325 19.6719 14.1172C19.3311 14.4867 19.1749 14.9242 19.2031 15.4297C19.1875 16.0703 19.1719 16.7109 19.1563 17.3515C18.9785 18.4668 18.33 19.1153 17.2109 19.2968C16.4171 19.3876 15.6202 19.4345 14.8203 19.4375C14.6558 19.4573 14.4996 19.5041 14.3516 19.5781C13.978 19.9048 13.6186 20.2485 13.2734 20.6093C12.8053 21.0619 12.274 21.4212 11.6797 21.6875C10.9165 21.9067 10.2134 21.7817 9.57032 21.3125C8.97655 20.7812 8.41405 20.2187 7.88282 19.625C7.58118 19.3415 7.22183 19.2009 6.80469 19.2031C3.74966 19.6167 2.39809 18.2964 2.75001 15.2422C2.77494 14.7632 2.63431 14.3414 2.32813 13.9765C1.78125 13.4922 1.26563 12.9765 0.781256 12.4297C0.125105 11.5554 0.0782299 10.6492 0.640631 9.71091C1.12008 9.09061 1.65134 8.51246 2.23438 7.97653C2.56328 7.56816 2.73516 7.09941 2.75001 6.57028C2.75405 5.88066 2.7853 5.19314 2.84376 4.50778C3.06515 3.58325 3.63546 2.99732 4.55469 2.74997C5.33277 2.65826 6.11404 2.61139 6.89844 2.60935C7.21921 2.5662 7.51612 2.45682 7.78907 2.28122C8.38457 1.73249 8.99394 1.20124 9.61719 0.687472C9.97012 0.468579 10.3451 0.32014 10.7422 0.242159ZM10.8359 1.69528C11.0475 1.69941 11.235 1.76972 11.3984 1.90622C11.9609 2.43747 12.5234 2.96872 13.0859 3.49997C13.5672 3.88894 14.1141 4.13897 14.7266 4.24997C15.3818 4.29994 16.0381 4.33121 16.6953 4.34372C17.0189 4.36214 17.2767 4.49494 17.4688 4.74216C17.5348 4.90889 17.5816 5.08078 17.6094 5.25778C17.6211 5.94628 17.6524 6.6338 17.7031 7.32028C17.7838 7.78121 17.9556 8.20308 18.2188 8.58591C18.7955 9.20953 19.3892 9.81891 20 10.414C20.1238 10.5835 20.2097 10.771 20.2578 10.9765C20.1611 11.2169 20.0282 11.4357 19.8594 11.6328C19.3424 12.1342 18.8423 12.6498 18.3594 13.1797C18.0054 13.6004 17.7866 14.0848 17.7031 14.6328C17.6524 15.3193 17.6211 16.0068 17.6094 16.6953C17.591 17.0188 17.4582 17.2766 17.2109 17.4687C17.0442 17.5347 16.8723 17.5816 16.6953 17.6093C16.0389 17.6378 15.3827 17.669 14.7266 17.7031C13.6811 17.8386 12.8764 18.3464 12.3125 19.2265C12.0534 19.4856 11.7956 19.7434 11.5391 20C11.3696 20.1238 11.1821 20.2097 10.9766 20.2578C10.7711 20.2097 10.5836 20.1238 10.4141 20C9.97396 19.6067 9.58335 19.1693 9.24219 18.6875C8.69929 18.1738 8.05869 17.8457 7.32032 17.7031C6.63374 17.6537 5.94623 17.6225 5.25782 17.6093C4.93429 17.5909 4.67648 17.4581 4.48438 17.2109C4.41838 17.0442 4.37151 16.8723 4.34376 16.6953C4.33199 16.0068 4.30077 15.3193 4.25001 14.6328C4.16938 14.1719 3.99754 13.75 3.73438 13.3672C3.15764 12.7435 2.56389 12.1342 1.95313 11.539C1.83569 11.3745 1.74975 11.1948 1.69532 11C1.78554 10.7493 1.91835 10.5228 2.09376 10.3203C2.57955 9.85017 3.0483 9.36577 3.50001 8.86716C3.88898 8.38594 4.13901 7.83905 4.25001 7.22653C4.30138 6.57136 4.33265 5.91511 4.34376 5.25778C4.36719 4.67185 4.67188 4.36716 5.25782 4.34372C5.89954 4.33224 6.54018 4.30097 7.17969 4.24997C7.80013 4.12721 8.36263 3.87722 8.86719 3.49997C9.27229 3.11044 9.66294 2.70418 10.0391 2.28122C10.2746 2.03912 10.5402 1.84381 10.8359 1.69528Z"
                                                                fill="white"
                                                            />
                                                            <path
                                                                opacity="0.959"
                                                                fill-rule="evenodd"
                                                                clip-rule="evenodd"
                                                                d="M13.6953 7.69531C14.5874 7.6573 14.9077 8.06356 14.6562 8.91406C13.2354 10.6241 11.8057 12.3272 10.3672 14.0234C10.1639 14.1368 9.95298 14.2306 9.73436 14.3047C9.57573 14.2779 9.42728 14.2232 9.28905 14.1406C8.64062 13.5547 7.99216 12.9687 7.34373 12.3828C7.20944 12.0926 7.19378 11.7957 7.29686 11.4922C7.43561 11.2351 7.65437 11.1101 7.95311 11.1172C8.16203 11.1245 8.35736 11.1792 8.53905 11.2812C8.92187 11.6328 9.30466 11.9844 9.68748 12.3359C10.8594 10.9297 12.0312 9.52344 13.2031 8.11719C13.3486 7.94778 13.5126 7.80715 13.6953 7.69531Z"
                                                                fill="white"
                                                            />
                                                        </g>
                                                        <defs>
                                                            <clipPath id="clip0_44_11">
                                                                <rect width="22" height="22" fill="white" />
                                                            </clipPath>
                                                        </defs>
                                                    </svg>
                                                    Elegant Vein Patterns
                                                </li>
                                            </ul>
                                            <a class="arrow-link" href="service-details.php">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="16" viewBox="0 0 26 16" fill="none">
                                                    <path
                                                        d="M25.7071 8.70711C26.0976 8.31658 26.0976 7.68342 25.7071 7.29289L19.3431 0.928932C18.9526 0.538408 18.3195 0.538408 17.9289 0.928932C17.5384 1.31946 17.5384 1.95262 17.9289 2.34315L23.5858 8L17.9289 13.6569C17.5384 14.0474 17.5384 14.6805 17.9289 15.0711C18.3195 15.4616 18.9526 15.4616 19.3431 15.0711L25.7071 8.70711ZM0 9H25V7H0V9Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="offer-card style1 img-custom-anim-left wow fadeInUp" data-wow-delay=".5s">
                                        <div class="bg"><img src="assets/images/offer/offerCardBg1_1.jpg" alt="bg" /></div>
                                        <div class="content">
                                            <div class="icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="none">
                                                    <g clip-path="url(#clip0_46_266)">
                                                        <path
                                                            opacity="0.969"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M35.4297 -0.0390625C35.9505 -0.0390625 36.4713 -0.0390625 36.9922 -0.0390625C38.5287 0.403646 39.5182 1.39323 39.9609 2.92969C39.9609 3.45052 39.9609 3.97135 39.9609 4.49219C39.7838 5.27525 39.3932 5.93931 38.7891 6.48438C37.1484 7.38281 35.5078 8.28125 33.8672 9.17969C34.4483 9.72133 34.9561 10.3203 35.3906 10.9766C36.2323 12.9078 35.9328 14.6396 34.4922 16.1719C34.2516 16.3508 34.0041 16.5201 33.75 16.6797C33.6201 17.8129 33.9977 18.7373 34.8828 19.4531C36.9866 20.5338 37.8721 22.2655 37.5391 24.6484C38.1868 25.0964 38.7988 25.5912 39.375 26.1328C39.6384 26.4963 39.8338 26.8869 39.9609 27.3047C39.9609 28.7891 39.9609 30.2734 39.9609 31.7578C39.6876 32.7219 39.0886 33.412 38.1641 33.8281C37.9656 34.0004 37.7963 34.1957 37.6562 34.4141C37.5294 34.9826 37.4252 35.5555 37.3438 36.1328C36.703 37.7736 35.4921 38.607 33.7109 38.6328C33.7239 38.9723 33.7109 39.3109 33.6719 39.6484C33.618 39.793 33.5269 39.8972 33.3984 39.9609C22.3568 39.9609 11.3151 39.9609 0.273438 39.9609C0.143229 39.8828 0.0390625 39.7787 -0.0390625 39.6484C-0.0390625 29.4401 -0.0390625 19.2318 -0.0390625 9.02344C0.0247215 8.895 0.128888 8.80391 0.273438 8.75C1.62735 8.71094 2.98152 8.69789 4.33594 8.71094C4.52783 6.64784 5.59554 5.25461 7.53906 4.53125C8.3175 4.38705 9.09875 4.25685 9.88281 4.14062C10.1298 4.03023 10.3641 3.90002 10.5859 3.75C11.0913 3.06207 11.7163 2.5152 12.4609 2.10938C12.7167 2.01545 12.9771 1.93732 13.2422 1.875C16.5004 1.79907 19.7556 1.82511 23.0078 1.95312C24.309 2.26535 25.2985 2.99452 25.9766 4.14062C27.3192 3.92992 28.5432 4.21638 29.6484 5C30.026 5.3776 30.4037 5.75521 30.7812 6.13281C31.6927 4.4401 32.6041 2.7474 33.5156 1.05469C34.0716 0.536147 34.7095 0.171563 35.4297 -0.0390625ZM35.6641 1.28906C37.9111 1.25742 38.8616 2.35117 38.5156 4.57031C38.3953 4.8765 38.226 5.14994 38.0078 5.39062C36.2989 6.33081 34.5802 7.2553 32.8516 8.16406C32.4751 7.82672 32.1105 7.47515 31.7578 7.10938C32.7121 5.42236 33.6366 3.71663 34.5312 1.99219C34.8479 1.64578 35.2255 1.41141 35.6641 1.28906ZM14.0234 3.08594C16.8377 3.0528 19.6502 3.09186 22.4609 3.20312C23.424 3.38566 24.1792 3.88045 24.7266 4.6875C23.9432 5.237 23.3573 5.95314 22.9688 6.83594C21.5778 10.5659 20.1716 14.2899 18.75 18.0078C18.4684 19.7257 19.1585 20.8064 20.8203 21.25C21.2425 21.3103 21.6592 21.2843 22.0703 21.1719C25.5275 19.833 28.991 18.5179 32.4609 17.2266C32.4909 19.0667 33.3502 20.3558 35.0391 21.0938C35.4846 21.4348 35.8102 21.8645 36.0156 22.3828C36.1509 23.3984 36.255 24.414 36.3281 25.4297C36.9141 25.8594 37.5 26.2891 38.0859 26.7188C38.3196 26.9523 38.4888 27.2258 38.5938 27.5391C38.6687 28.9505 38.6427 30.3567 38.5156 31.7578C38.1855 32.2291 37.7558 32.5807 37.2266 32.8125C36.407 33.5805 36.0294 34.5309 36.0938 35.6641C35.6773 36.7396 34.883 37.2865 33.7109 37.3047C33.724 32.8775 33.7109 28.4505 33.6719 24.0234C33.6328 23.8802 33.5416 23.7891 33.3984 23.75C32.6698 23.7109 31.9405 23.698 31.2109 23.7109C31.224 22.3565 31.2109 21.0023 31.1719 19.6484C31.0524 19.4128 30.8571 19.3087 30.5859 19.3359C30.3148 19.3087 30.1195 19.4128 30 19.6484C29.9609 21.0023 29.9479 22.3565 29.9609 23.7109C29.3359 23.7109 28.7109 23.7109 28.0859 23.7109C28.0989 22.9813 28.0859 22.2521 28.0469 21.5234C27.9274 21.2878 27.7321 21.1837 27.4609 21.2109C27.1898 21.1837 26.9945 21.2878 26.875 21.5234C26.8359 22.2521 26.823 22.9813 26.8359 23.7109C26.2109 23.7109 25.5859 23.7109 24.9609 23.7109C24.9739 23.1895 24.9609 22.6686 24.9219 22.1484C24.8024 21.9128 24.6071 21.8087 24.3359 21.8359C24.0648 21.8087 23.8695 21.9128 23.75 22.1484C23.7109 22.6686 23.698 23.1895 23.7109 23.7109C21.6276 23.7109 19.5443 23.7109 17.4609 23.7109C17.474 18.815 17.4609 13.9192 17.4219 9.02344C17.3828 8.88023 17.2916 8.78906 17.1484 8.75C16.837 8.71102 16.5245 8.69797 16.2109 8.71094C16.224 7.77308 16.2109 6.83558 16.1719 5.89844C16.0524 5.66281 15.8571 5.55864 15.5859 5.58594C15.3148 5.55864 15.1195 5.66281 15 5.89844C14.9609 6.83558 14.9479 7.77308 14.9609 8.71094C14.3359 8.71094 13.7109 8.71094 13.0859 8.71094C13.0989 7.98133 13.0859 7.25214 13.0469 6.52344C12.9274 6.28781 12.7321 6.18364 12.4609 6.21094C12.1898 6.18364 11.9945 6.28781 11.875 6.52344C11.8359 7.25214 11.823 7.98133 11.8359 8.71094C9.77867 8.71094 7.72135 8.71094 5.66406 8.71094C5.75943 7.67347 6.22818 6.85316 7.07031 6.25C7.90641 5.74545 8.81789 5.51107 9.80469 5.54688C10.3851 5.43887 10.9059 5.20449 11.3672 4.84375C11.8141 4.39681 12.2568 3.95411 12.6953 3.51562C13.1204 3.28631 13.5631 3.14309 14.0234 3.08594ZM26.4453 5.42969C27.2321 5.35295 27.9613 5.52222 28.6328 5.9375C29.1133 6.32677 29.5559 6.75645 29.9609 7.22656C29.2069 8.01977 28.4386 8.80102 27.6562 9.57031C27.1875 10.3776 27.1875 11.1849 27.6562 11.9922C28.5075 12.813 29.432 12.9041 30.4297 12.2656C31.1979 11.4974 31.9662 10.7291 32.7344 9.96094C33.373 10.4947 33.8938 11.1197 34.2969 11.8359C34.7741 13.1952 34.4747 14.354 33.3984 15.3125C29.3848 16.9615 25.3353 18.5109 21.25 19.9609C20.2791 19.7911 19.8884 19.2182 20.0781 18.2422C21.4477 14.6805 22.8018 11.1129 24.1406 7.53906C24.5532 6.43591 25.3215 5.73279 26.4453 5.42969ZM30.8984 8.24219C31.2164 8.44219 31.5028 8.68961 31.7578 8.98438C31.0026 9.73961 30.2474 10.4948 29.4922 11.25C28.8547 11.4202 28.5812 11.1727 28.6719 10.5078C29.4298 9.76289 30.172 9.00766 30.8984 8.24219ZM1.21094 9.96094C6.21094 9.96094 11.2109 9.96094 16.2109 9.96094C16.2109 14.5443 16.2109 19.1276 16.2109 23.7109C11.2109 23.7109 6.21094 23.7109 1.21094 23.7109C1.21094 19.1276 1.21094 14.5443 1.21094 9.96094ZM1.21094 24.9609C6.21094 24.9609 11.2109 24.9609 16.2109 24.9609C16.2109 29.5443 16.2109 34.1276 16.2109 38.7109C11.2109 38.7109 6.21094 38.7109 1.21094 38.7109C1.21094 34.1276 1.21094 29.5443 1.21094 24.9609ZM17.4609 24.9609C22.4609 24.9609 27.4609 24.9609 32.4609 24.9609C32.4609 29.5443 32.4609 34.1276 32.4609 38.7109C27.4609 38.7109 22.4609 38.7109 17.4609 38.7109C17.4609 34.1276 17.4609 29.5443 17.4609 24.9609Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.879"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M35.8203 3.08594C36.5317 2.95152 36.8573 3.23798 36.7969 3.94532C36.7355 4.08485 36.6445 4.20203 36.5234 4.29688C35.945 4.49692 35.6065 4.30161 35.5078 3.71094C35.5384 3.46088 35.6427 3.25255 35.8203 3.08594Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.972"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M19.0234 4.96094C19.2333 4.94812 19.4417 4.96114 19.6484 5C19.7916 5.03906 19.8828 5.13021 19.9219 5.27344C19.974 6.52344 19.974 7.77344 19.9219 9.02344C19.8024 9.25906 19.6071 9.3632 19.3359 9.33594C19.0648 9.3632 18.8694 9.25906 18.75 9.02344C18.6979 7.77344 18.6979 6.52344 18.75 5.27344C18.8039 5.12889 18.895 5.02472 19.0234 4.96094Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.892"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M19.0235 10.5859C19.911 10.5242 20.1713 10.9018 19.8047 11.7188C18.9816 12.031 18.63 11.7576 18.75 10.8984C18.8039 10.7539 18.895 10.6497 19.0235 10.5859Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.983"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M14.0234 16.8359C14.2334 16.8231 14.4417 16.8362 14.6484 16.875C14.7916 16.9141 14.8828 17.0052 14.9219 17.1484C14.9983 18.8741 14.9722 20.5929 14.8438 22.3047C14.7852 22.3536 14.72 22.3927 14.6484 22.4219C13.3984 22.474 12.1484 22.474 10.8984 22.4219C10.6628 22.3024 10.5587 22.1071 10.5859 21.8359C10.5587 21.5648 10.6628 21.3695 10.8984 21.25C11.8355 21.2109 12.773 21.1979 13.7109 21.2109C13.6979 19.8565 13.7109 18.5023 13.75 17.1484C13.8039 17.0039 13.895 16.8997 14.0234 16.8359Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.892"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M8.39845 21.2109C9.28595 21.1492 9.54634 21.5268 9.1797 22.3438C8.35658 22.656 8.00501 22.3826 8.12501 21.5234C8.17892 21.3789 8.27001 21.2747 8.39845 21.2109Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.972"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M35.2734 27.4609C35.4833 27.4481 35.6917 27.4612 35.8984 27.5C36.0416 27.5391 36.1328 27.6302 36.1719 27.7734C36.224 29.0234 36.224 30.2734 36.1719 31.5234C36.0524 31.7591 35.8571 31.8632 35.5859 31.8359C35.3148 31.8632 35.1194 31.7591 35 31.5234C34.9479 30.2734 34.9479 29.0234 35 27.7734C35.0539 27.6289 35.145 27.5247 35.2734 27.4609Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.983"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M14.0234 31.8359C14.2334 31.8231 14.4417 31.8362 14.6484 31.875C14.7916 31.9141 14.8828 32.0052 14.9219 32.1484C14.9983 33.8741 14.9722 35.5929 14.8438 37.3047C14.7852 37.3536 14.72 37.3927 14.6484 37.4219C13.3984 37.474 12.1484 37.474 10.8984 37.4219C10.6628 37.3024 10.5587 37.1071 10.5859 36.8359C10.5587 36.5648 10.6628 36.3695 10.8984 36.25C11.8355 36.2109 12.773 36.1979 13.7109 36.2109C13.6979 34.8565 13.7109 33.5023 13.75 32.1484C13.8039 32.0039 13.895 31.8997 14.0234 31.8359Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.983"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M30.2734 31.8359C30.4834 31.8231 30.6917 31.8362 30.8984 31.875C31.0416 31.9141 31.1328 32.0052 31.1719 32.1484C31.2483 33.8741 31.2222 35.5929 31.0938 37.3047C31.0352 37.3536 30.97 37.3927 30.8984 37.4219C29.6484 37.474 28.3984 37.474 27.1484 37.4219C26.9128 37.3024 26.8087 37.1071 26.8359 36.8359C26.8087 36.5648 26.9128 36.3695 27.1484 36.25C28.0855 36.2109 29.023 36.1979 29.9609 36.2109C29.9479 34.8565 29.9609 33.5023 30 32.1484C30.0539 32.0039 30.145 31.8997 30.2734 31.8359Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.892"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M8.39845 36.2109C9.28595 36.1492 9.54634 36.5268 9.1797 37.3437C8.35658 37.656 8.00501 37.3826 8.12501 36.5234C8.17892 36.3789 8.27001 36.2747 8.39845 36.2109Z"
                                                            fill="white"
                                                        />
                                                        <path
                                                            opacity="0.892"
                                                            fill-rule="evenodd"
                                                            clip-rule="evenodd"
                                                            d="M24.6485 36.2109C25.536 36.1492 25.7963 36.5268 25.4297 37.3437C24.6066 37.656 24.255 37.3826 24.375 36.5234C24.4289 36.3789 24.52 36.2747 24.6485 36.2109Z"
                                                            fill="white"
                                                        />
                                                    </g>
                                                    <defs>
                                                        <clipPath id="clip0_46_266">
                                                            <rect width="40" height="40" fill="white" />
                                                        </clipPath>
                                                    </defs>
                                                </svg>
                                            </div>
                                            <h3>
                                                <a href="service-details.php">Floor Remove</a>
                                            </h3>
                                            <p class="text">There are many flo variations of passages of atitl Lorem Ipsum available, but thedw,</p>
                                            <ul class="checklist style1">
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22" fill="none">
                                                        <g clip-path="url(#clip0_44_12)">
                                                            <path
                                                                opacity="0.964"
                                                                fill-rule="evenodd"
                                                                clip-rule="evenodd"
                                                                d="M10.7422 0.242159C11.2869 0.214254 11.7869 0.347065 12.2422 0.640597C12.8625 1.12005 13.4406 1.6513 13.9766 2.23435C14.2725 2.49163 14.6163 2.64788 15.0078 2.7031C15.7898 2.74525 16.5711 2.79212 17.3516 2.84372C18.2812 3.08591 18.8672 3.67185 19.1094 4.60153C19.1672 5.31844 19.1984 6.03717 19.2031 6.75778C19.1858 7.22025 19.3265 7.62652 19.625 7.97653C20.2393 8.54367 20.8018 9.15305 21.3125 9.80466C21.8012 10.5826 21.8324 11.3795 21.4063 12.1953C20.8975 12.8919 20.3194 13.5325 19.6719 14.1172C19.3311 14.4867 19.1749 14.9242 19.2031 15.4297C19.1875 16.0703 19.1719 16.7109 19.1563 17.3515C18.9785 18.4668 18.33 19.1153 17.2109 19.2968C16.4171 19.3876 15.6202 19.4345 14.8203 19.4375C14.6558 19.4573 14.4996 19.5041 14.3516 19.5781C13.978 19.9048 13.6186 20.2485 13.2734 20.6093C12.8053 21.0619 12.274 21.4212 11.6797 21.6875C10.9165 21.9067 10.2134 21.7817 9.57032 21.3125C8.97655 20.7812 8.41405 20.2187 7.88282 19.625C7.58118 19.3415 7.22183 19.2009 6.80469 19.2031C3.74966 19.6167 2.39809 18.2964 2.75001 15.2422C2.77494 14.7632 2.63431 14.3414 2.32813 13.9765C1.78125 13.4922 1.26563 12.9765 0.781256 12.4297C0.125105 11.5554 0.0782299 10.6492 0.640631 9.71091C1.12008 9.09061 1.65134 8.51246 2.23438 7.97653C2.56328 7.56816 2.73516 7.09941 2.75001 6.57028C2.75405 5.88066 2.7853 5.19314 2.84376 4.50778C3.06515 3.58325 3.63546 2.99732 4.55469 2.74997C5.33277 2.65826 6.11404 2.61139 6.89844 2.60935C7.21921 2.5662 7.51612 2.45682 7.78907 2.28122C8.38457 1.73249 8.99394 1.20124 9.61719 0.687472C9.97012 0.468579 10.3451 0.32014 10.7422 0.242159ZM10.8359 1.69528C11.0475 1.69941 11.235 1.76972 11.3984 1.90622C11.9609 2.43747 12.5234 2.96872 13.0859 3.49997C13.5672 3.88894 14.1141 4.13897 14.7266 4.24997C15.3818 4.29994 16.0381 4.33121 16.6953 4.34372C17.0189 4.36214 17.2767 4.49494 17.4688 4.74216C17.5348 4.90889 17.5816 5.08078 17.6094 5.25778C17.6211 5.94628 17.6524 6.6338 17.7031 7.32028C17.7838 7.78121 17.9556 8.20308 18.2188 8.58591C18.7955 9.20953 19.3892 9.81891 20 10.414C20.1238 10.5835 20.2097 10.771 20.2578 10.9765C20.1611 11.2169 20.0282 11.4357 19.8594 11.6328C19.3424 12.1342 18.8423 12.6498 18.3594 13.1797C18.0054 13.6004 17.7866 14.0848 17.7031 14.6328C17.6524 15.3193 17.6211 16.0068 17.6094 16.6953C17.591 17.0188 17.4582 17.2766 17.2109 17.4687C17.0442 17.5347 16.8723 17.5816 16.6953 17.6093C16.0389 17.6378 15.3827 17.669 14.7266 17.7031C13.6811 17.8386 12.8764 18.3464 12.3125 19.2265C12.0534 19.4856 11.7956 19.7434 11.5391 20C11.3696 20.1238 11.1821 20.2097 10.9766 20.2578C10.7711 20.2097 10.5836 20.1238 10.4141 20C9.97396 19.6067 9.58335 19.1693 9.24219 18.6875C8.69929 18.1738 8.05869 17.8457 7.32032 17.7031C6.63374 17.6537 5.94623 17.6225 5.25782 17.6093C4.93429 17.5909 4.67648 17.4581 4.48438 17.2109C4.41838 17.0442 4.37151 16.8723 4.34376 16.6953C4.33199 16.0068 4.30077 15.3193 4.25001 14.6328C4.16938 14.1719 3.99754 13.75 3.73438 13.3672C3.15764 12.7435 2.56389 12.1342 1.95313 11.539C1.83569 11.3745 1.74975 11.1948 1.69532 11C1.78554 10.7493 1.91835 10.5228 2.09376 10.3203C2.57955 9.85017 3.0483 9.36577 3.50001 8.86716C3.88898 8.38594 4.13901 7.83905 4.25001 7.22653C4.30138 6.57136 4.33265 5.91511 4.34376 5.25778C4.36719 4.67185 4.67188 4.36716 5.25782 4.34372C5.89954 4.33224 6.54018 4.30097 7.17969 4.24997C7.80013 4.12721 8.36263 3.87722 8.86719 3.49997C9.27229 3.11044 9.66294 2.70418 10.0391 2.28122C10.2746 2.03912 10.5402 1.84381 10.8359 1.69528Z"
                                                                fill="white"
                                                            />
                                                            <path
                                                                opacity="0.959"
                                                                fill-rule="evenodd"
                                                                clip-rule="evenodd"
                                                                d="M13.6953 7.69531C14.5874 7.6573 14.9077 8.06356 14.6562 8.91406C13.2354 10.6241 11.8057 12.3272 10.3672 14.0234C10.1639 14.1368 9.95298 14.2306 9.73436 14.3047C9.57573 14.2779 9.42728 14.2232 9.28905 14.1406C8.64062 13.5547 7.99216 12.9687 7.34373 12.3828C7.20944 12.0926 7.19378 11.7957 7.29686 11.4922C7.43561 11.2351 7.65437 11.1101 7.95311 11.1172C8.16203 11.1245 8.35736 11.1792 8.53905 11.2812C8.92187 11.6328 9.30466 11.9844 9.68748 12.3359C10.8594 10.9297 12.0312 9.52344 13.2031 8.11719C13.3486 7.94778 13.5126 7.80715 13.6953 7.69531Z"
                                                                fill="white"
                                                            />
                                                        </g>
                                                        <defs>
                                                            <clipPath id="clip0_44_12">
                                                                <rect width="22" height="22" fill="white" />
                                                            </clipPath>
                                                        </defs>
                                                    </svg>
                                                    More Expensive
                                                </li>
                                                <li>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22" fill="none">
                                                        <g clip-path="url(#clip0_44_13)">
                                                            <path
                                                                opacity="0.964"
                                                                fill-rule="evenodd"
                                                                clip-rule="evenodd"
                                                                d="M10.7422 0.242159C11.2869 0.214254 11.7869 0.347065 12.2422 0.640597C12.8625 1.12005 13.4406 1.6513 13.9766 2.23435C14.2725 2.49163 14.6163 2.64788 15.0078 2.7031C15.7898 2.74525 16.5711 2.79212 17.3516 2.84372C18.2812 3.08591 18.8672 3.67185 19.1094 4.60153C19.1672 5.31844 19.1984 6.03717 19.2031 6.75778C19.1858 7.22025 19.3265 7.62652 19.625 7.97653C20.2393 8.54367 20.8018 9.15305 21.3125 9.80466C21.8012 10.5826 21.8324 11.3795 21.4063 12.1953C20.8975 12.8919 20.3194 13.5325 19.6719 14.1172C19.3311 14.4867 19.1749 14.9242 19.2031 15.4297C19.1875 16.0703 19.1719 16.7109 19.1563 17.3515C18.9785 18.4668 18.33 19.1153 17.2109 19.2968C16.4171 19.3876 15.6202 19.4345 14.8203 19.4375C14.6558 19.4573 14.4996 19.5041 14.3516 19.5781C13.978 19.9048 13.6186 20.2485 13.2734 20.6093C12.8053 21.0619 12.274 21.4212 11.6797 21.6875C10.9165 21.9067 10.2134 21.7817 9.57032 21.3125C8.97655 20.7812 8.41405 20.2187 7.88282 19.625C7.58118 19.3415 7.22183 19.2009 6.80469 19.2031C3.74966 19.6167 2.39809 18.2964 2.75001 15.2422C2.77494 14.7632 2.63431 14.3414 2.32813 13.9765C1.78125 13.4922 1.26563 12.9765 0.781256 12.4297C0.125105 11.5554 0.0782299 10.6492 0.640631 9.71091C1.12008 9.09061 1.65134 8.51246 2.23438 7.97653C2.56328 7.56816 2.73516 7.09941 2.75001 6.57028C2.75405 5.88066 2.7853 5.19314 2.84376 4.50778C3.06515 3.58325 3.63546 2.99732 4.55469 2.74997C5.33277 2.65826 6.11404 2.61139 6.89844 2.60935C7.21921 2.5662 7.51612 2.45682 7.78907 2.28122C8.38457 1.73249 8.99394 1.20124 9.61719 0.687472C9.97012 0.468579 10.3451 0.32014 10.7422 0.242159ZM10.8359 1.69528C11.0475 1.69941 11.235 1.76972 11.3984 1.90622C11.9609 2.43747 12.5234 2.96872 13.0859 3.49997C13.5672 3.88894 14.1141 4.13897 14.7266 4.24997C15.3818 4.29994 16.0381 4.33121 16.6953 4.34372C17.0189 4.36214 17.2767 4.49494 17.4688 4.74216C17.5348 4.90889 17.5816 5.08078 17.6094 5.25778C17.6211 5.94628 17.6524 6.6338 17.7031 7.32028C17.7838 7.78121 17.9556 8.20308 18.2188 8.58591C18.7955 9.20953 19.3892 9.81891 20 10.414C20.1238 10.5835 20.2097 10.771 20.2578 10.9765C20.1611 11.2169 20.0282 11.4357 19.8594 11.6328C19.3424 12.1342 18.8423 12.6498 18.3594 13.1797C18.0054 13.6004 17.7866 14.0848 17.7031 14.6328C17.6524 15.3193 17.6211 16.0068 17.6094 16.6953C17.591 17.0188 17.4582 17.2766 17.2109 17.4687C17.0442 17.5347 16.8723 17.5816 16.6953 17.6093C16.0389 17.6378 15.3827 17.669 14.7266 17.7031C13.6811 17.8386 12.8764 18.3464 12.3125 19.2265C12.0534 19.4856 11.7956 19.7434 11.5391 20C11.3696 20.1238 11.1821 20.2097 10.9766 20.2578C10.7711 20.2097 10.5836 20.1238 10.4141 20C9.97396 19.6067 9.58335 19.1693 9.24219 18.6875C8.69929 18.1738 8.05869 17.8457 7.32032 17.7031C6.63374 17.6537 5.94623 17.6225 5.25782 17.6093C4.93429 17.5909 4.67648 17.4581 4.48438 17.2109C4.41838 17.0442 4.37151 16.8723 4.34376 16.6953C4.33199 16.0068 4.30077 15.3193 4.25001 14.6328C4.16938 14.1719 3.99754 13.75 3.73438 13.3672C3.15764 12.7435 2.56389 12.1342 1.95313 11.539C1.83569 11.3745 1.74975 11.1948 1.69532 11C1.78554 10.7493 1.91835 10.5228 2.09376 10.3203C2.57955 9.85017 3.0483 9.36577 3.50001 8.86716C3.88898 8.38594 4.13901 7.83905 4.25001 7.22653C4.30138 6.57136 4.33265 5.91511 4.34376 5.25778C4.36719 4.67185 4.67188 4.36716 5.25782 4.34372C5.89954 4.33224 6.54018 4.30097 7.17969 4.24997C7.80013 4.12721 8.36263 3.87722 8.86719 3.49997C9.27229 3.11044 9.66294 2.70418 10.0391 2.28122C10.2746 2.03912 10.5402 1.84381 10.8359 1.69528Z"
                                                                fill="white"
                                                            />
                                                            <path
                                                                opacity="0.959"
                                                                fill-rule="evenodd"
                                                                clip-rule="evenodd"
                                                                d="M13.6953 7.69531C14.5874 7.6573 14.9077 8.06356 14.6562 8.91406C13.2354 10.6241 11.8057 12.3272 10.3672 14.0234C10.1639 14.1368 9.95298 14.2306 9.73436 14.3047C9.57573 14.2779 9.42728 14.2232 9.28905 14.1406C8.64062 13.5547 7.99216 12.9687 7.34373 12.3828C7.20944 12.0926 7.19378 11.7957 7.29686 11.4922C7.43561 11.2351 7.65437 11.1101 7.95311 11.1172C8.16203 11.1245 8.35736 11.1792 8.53905 11.2812C8.92187 11.6328 9.30466 11.9844 9.68748 12.3359C10.8594 10.9297 12.0312 9.52344 13.2031 8.11719C13.3486 7.94778 13.5126 7.80715 13.6953 7.69531Z"
                                                                fill="white"
                                                            />
                                                        </g>
                                                        <defs>
                                                            <clipPath id="clip0_44_13">
                                                                <rect width="22" height="22" fill="white" />
                                                            </clipPath>
                                                        </defs>
                                                    </svg>
                                                    Elegant Vein Patterns
                                                </li>
                                            </ul>
                                            <a class="arrow-link" href="service-details.php">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="16" viewBox="0 0 26 16" fill="none">
                                                    <path
                                                        d="M25.7071 8.70711C26.0976 8.31658 26.0976 7.68342 25.7071 7.29289L19.3431 0.928932C18.9526 0.538408 18.3195 0.538408 17.9289 0.928932C17.5384 1.31946 17.5384 1.95262 17.9289 2.34315L23.5858 8L17.9289 13.6569C17.5384 14.0474 17.5384 14.6805 17.9289 15.0711C18.3195 15.4616 18.9526 15.4616 19.3431 15.0711L25.7071 8.70711ZM0 9H25V7H0V9Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="slider-pagination"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->

        <!-- Wcu Section    S T A R T -->
        <section class="wcu-section section-padding fix">
            <div class="wcu-container-wrapper style1">
                <div class="shape"><img src="assets/images/shape/wcuShape1_1.png" alt="shape" /></div>
                <div class="container">
                    <div class="wcu-wrapper style1">
                        <div class="row gy-5 gx-60">
                            <div class="col-xl-6">
                                <div class="wcu-thumb img-custom-anim-left wow fadeInUp" data-wow-delay=".5s">
                                    <img class="thumb1" src="assets/images/wcu/wcuThumb1_1.jpg" alt="thumb" />
                                    <img class="thumb2" src="assets/images/wcu/wcuThumb1_2.jpg" alt="thumb" />

                                    <div class="thumbShape1 float-bob-x"><img src="assets/images/shape/wcuThumbShape1_1.png" alt="shape" /></div>

                                    <div class="thumbShape2 float-bob-x"><img src="assets/images/shape/wcuThumbShape1_2.png" alt="shape" /></div>

                                    <div class="thumbShape3 float-bob-y"><img src="assets/images/shape/wcuThumbShape1_3.png" alt="shape" /></div>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="wcu-content">
                                    <div class="section-title text-start mt-70">
                                        <!-- <div class="subtitle text-start wow fadeInUp" data-wow-delay=".5s"><img class="me-1" src="assets/images/shape/titleShape1_1.png" alt="icon" /> RELIABLE</div> -->
                                        <h2 class="text-start mt-15 wow fadeInUp" data-wow-delay=".8s">Marble Decor</h2>
                                        <p class="desc wow fadeInUp" data-wow-delay=".7s">
                                        Established in the year 2007 at Coimbatore, Tamil Nadu, We “Marble Decor” are a Proprietorship based firm, engaged as the foremost Wholesale Trader of Interior, Tiles, Granite, etc.
                                        </p>
                                    </div>
                                    <div class="fancy-box style2 wow fadeInUp" data-wow-delay=".5s">
                                        <div class="fancy-item">
                                            <div class="icon">
                                                <img src="assets/images/icon/wcuIcon1_1.svg" alt="icon" />
                                            </div>
                                        </div>
                                        <div class="fancy-item">
                                            <h4>Premium Flooring Expertise</h4>
                                            <p>Marble Decor is a trusted wholesale & retail dealer in South India, offering a vast collection of premium flooring solutions like Imported Marble, Granite, Quartz, and more.</p>
                                        </div>
                                    </div>
                                    <div class="fancy-box style2 wow fadeInUp" data-wow-delay=".7s">
                                        <div class="fancy-item">
                                            <div class="icon">
                                                <img src="assets/images/icon/wcuIcon1_2.svg" alt="icon" />
                                            </div>
                                        </div>
                                        <div class="fancy-item">
                                            <h4>South India’s Flooring Leader</h4>
                                            <p>From Coimbatore to across South India, Marble Decor stands as a leading provider of exclusive Imported Marbles and Stones, known for quality, range, and elegance.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Testimonial Section    S T A R T -->
        <!-- <div class="testimonial-section section-padding">
            <div class="testimonial-container-wrapper style1">
                <div class="shape1 d-none d-xxl-block">
                    <img src="assets/images/shape/testimonialShape1_1.png" alt="shape" />
                </div>
                <div class="shape2 d-none d-xxl-block">
                    <img src="assets/images/shape/testimonialShape1_2.png" alt="shape" />
                </div>

                <div class="container">
                    <div class="row d-flex align-items-end mt-70 mb-60">
                        <div class="col-xl-6">
                            <div class="section-title text-start mxw-530">
                                <div class="subtitle text-start wow fadeInUp" data-wow-delay=".5s"><img class="me-1" src="assets/images/shape/titleShape1_1.png" alt="icon" /> TESTIMONIAL</div>
                                <h2 class="text-start mt-15 wow fadeInUp" data-wow-delay=".3s">What People Say About Services</h2>
                            </div>
                        </div>
                        <div class="col-xl-6 d-flex justify-content-start justify-content-xl-end mt-4 mt-xl-0">
                            <div class="slider-arrow-btn text-end wow fadeInUp" data-wow-delay=".9s">
                                <button data-slider-prev="#testimonialSliderOne" class="slider-arrow style1"><i class="fa-solid fa-arrow-left-long"></i></button>
                                <button data-slider-next="#testimonialSliderOne" class="slider-arrow style1 slider-next"><i class="fa-solid fa-arrow-right-long"></i></button>
                            </div>
                        </div>
                    </div>

                    <div class="slider-area testimonialSliderOne fix text-center">
                        <div
                            class="swiper gt-slider"
                            id="testimonialSliderOne"
                            data-slider-options='{"loop": true,"breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":1,"centeredSlides":true},"768":{"slidesPerView":1},"992":{"slidesPerView":2},"1200":{"slidesPerView":2}}}'
                        >
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <div class="testimonial-card-items style1 wow fadeInUp" data-wow-delay=".5s" data-bg-src="assets/images/bg/testimonialBg1_1.png">
                                        <div class="shape"><img src="assets/images/shape/testimonialCardShape1_1.png" alt="shape" /></div>

                                        <div class="profile-meta">
                                            <div class="thumb">
                                                <img src="assets/images/testimonial/testimonialProfile1_1.png" alt="thumb" />
                                            </div>
                                            <div class="content">
                                                <h6>Guy Hawkins</h6>
                                                <p>UI/UX Designer</p>
                                            </div>
                                        </div>
                                        <div class="body">
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by lorem injected humour, or randomised words which</p>
                                            <ul class="star-wrapper style1">
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="testimonial-card-items style1 wow fadeInUp" data-wow-delay=".7s" data-bg-src="assets/images/bg/testimonialBg1_1.png">
                                        <div class="shape"><img src="assets/images/shape/testimonialCardShape1_1.png" alt="shape" /></div>

                                        <div class="profile-meta">
                                            <div class="thumb">
                                                <img src="assets/images/testimonial/testimonialProfile1_2.png" alt="thumb" />
                                            </div>
                                            <div class="content">
                                                <h6>Jacob Jones</h6>
                                                <p>UI/UX Designer</p>
                                            </div>
                                        </div>
                                        <div class="body">
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by lorem injected humour, or randomised words which</p>
                                            <ul class="star-wrapper style1">
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="testimonial-card-items style1" data-bg-src="assets/images/bg/testimonialBg1_1.png">
                                        <div class="shape"><img src="assets/images/shape/testimonialCardShape1_1.png" alt="shape" /></div>

                                        <div class="profile-meta">
                                            <div class="thumb">
                                                <img src="assets/images/testimonial/testimonialProfile1_1.png" alt="thumb" />
                                            </div>
                                            <div class="content">
                                                <h6>Guy Hawkins</h6>
                                                <p>UI/UX Designer</p>
                                            </div>
                                        </div>
                                        <div class="body">
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by lorem injected humour, or randomised words which</p>
                                            <ul class="star-wrapper style1">
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="testimonial-card-items style1" data-bg-src="assets/images/bg/testimonialBg1_1.png">
                                        <div class="shape"><img src="assets/images/shape/testimonialCardShape1_1.png" alt="shape" /></div>

                                        <div class="profile-meta">
                                            <div class="thumb">
                                                <img src="assets/images/testimonial/testimonialProfile1_1.png" alt="thumb" />
                                            </div>
                                            <div class="content">
                                                <h6>Jacob Jones</h6>
                                                <p>UI/UX Designer</p>
                                            </div>
                                        </div>
                                        <div class="body">
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by lorem injected humour, or randomised words which</p>
                                            <ul class="star-wrapper style1">
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                                <li><img src="assets/images/icon/starIcon.svg" alt="icon" /></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="slider-pagination"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->

        <!-- Single shared modal (outside swiper, at bottom of page) -->
        <div class="video-popup-modal">
            <div class="video-popup-container">
                <span class="video-popup-close">&times;</span>
                <video controls autoplay controlslist="nodownload">
                    Your browser does not support the video tag.
                </video>
            </div>
        </div>

        <style>
            /* New container styling to prevent overflow */
            .video-container {
                width: 100%;
                overflow: hidden;
                position: relative;
            }
            
            /* Updated video preview styles */
            /* .video-preview {
                position: relative;
                width: 100%;
                height: 0;
                padding-bottom: 56.25%;
                background-size: cover;
                background-position: center;
                cursor: pointer;
                overflow: hidden;
            } */
            
            /* Modal styles adjusted for full-size display */
            .video-popup-modal {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.9);
                z-index: 9999;
                align-items: center;
                justify-content: center;
            }
            
            .video-popup-container {
                position: relative;
                width: 90%;
                max-width: 1200px;
                height: 90vh;
            }
            
            .video-popup-container video {
                width: 100%;
                height: 100%;
                object-fit: contain;
                display: block;
            }
            
            .video-popup-close {
                position: absolute;
                top: -40px;
                right: 0;
                color: white;
                font-size: 30px;
                cursor: pointer;
            }
            
            /* .play-btn {
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                z-index: 1;
            } */
        </style>

        <script>
            // Single event listener for all slides
            document.addEventListener('DOMContentLoaded', function() {
                const modal = document.querySelector('.video-popup-modal');
                const videoElement = document.querySelector('.video-popup-container video');
                const closeBtn = document.querySelector('.video-popup-close');
                
                // Handle all play buttons
                document.addEventListener('click', function(e) {
                    if (e.target.closest('.play-btn')) {
                        e.preventDefault();
                        const btn = e.target.closest('.play-btn');
                        const videoSrc = btn.getAttribute('data-video-src');
                        
                        videoElement.src = videoSrc;
                        modal.style.display = 'flex';
                        document.body.style.overflow = 'hidden';
                    }
                });
                
                // Close modal
                closeBtn.addEventListener('click', function() {
                    modal.style.display = 'none';
                    document.body.style.overflow = 'auto';
                    videoElement.pause();
                    videoElement.currentTime = 0;
                });
                
                // Close when clicking outside
                modal.addEventListener('click', function(e) {
                    if (e.target === modal) {
                        modal.style.display = 'none';
                        document.body.style.overflow = 'auto';
                        videoElement.pause();
                        videoElement.currentTime = 0;
                    }
                });
            });
        </script>

        <?php include "temp/footer.php" ?>

    </body>

</html>